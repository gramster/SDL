///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __CONSTANT_HXX
#define __CONSTANT_HXX

//////////////////////////////////////////////////////////////////////////
// The #defines for Menu items are defined as follows:			//
//									//
// Each identifier is prefixed by ID_					//
// ...									//
//////////////////////////////////////////////////////////////////////////

#define SDL_MENU			1
#define ID_FILE_NEW			11
#define ID_FILE_OPEN			12
#define ID_FILE_SAVE			13
#define ID_FILE_SAVE_AS			14
#define ID_FILE_EXPORT_SDLPR		151
#define ID_FILE_EXPORT_XFIG_PAGE	1521
#define ID_FILE_EXPORT_XFIG_ALL		1522
#define ID_FILE_EXIT			16

#define ID_CREATE_BLOCK			21
#define ID_CREATE_CONNECTOR		23
#define ID_CREATE_PROCESS_REFERENCE	211
#define ID_CREATE_PROCESS_START		212
#define ID_CREATE_PROCESS_STATE		213
#define ID_CREATE_PROCESS_INPUT		214
#define ID_CREATE_PROCESS_OUTPUT	215
#define ID_CREATE_PROCESS_SAVE		216
#define ID_CREATE_PROCESS_DECISION	217
#define ID_CREATE_PROCESS_ENABLE	218
#define ID_CREATE_PROCESS_STOP		219
#define ID_CREATE_MACRO_CALL		221
#define ID_CREATE_MACRO_INLET		222
#define ID_CREATE_MACRO_OUTLET		223
#define ID_CREATE_SERVICE		231
#define ID_CREATE_PRIORITY_INPUT	232
#define ID_CREATE_PRIORITY_OUTPUT	233
#define ID_CREATE_PROCEDURE_REFERENCE	241
#define ID_CREATE_PROCEDURE_CALL	242
#define ID_CREATE_PROCEDURE_RETURN	243
#define ID_CREATE_PROCEDURE_START	244
#define ID_CREATE_TASK			24
#define ID_CREATE_TEXT			25
#define ID_CREATE_TRANSITION		26

#define ID_CREATE_FLOW_LINE		31
#define ID_CREATE_CHANNEL		32
#define ID_CREATE_SIGNAL_ROUTE		33

#define ID_EDIT_MOVE			41
#define ID_EDIT_DELETE			42
#define ID_EDIT_RESIZE			43

#define ID_VIEW_REFRESH			51
#define ID_VIEW_GRID_1			521
#define ID_VIEW_GRID_5			522
#define ID_VIEW_GRID_10			523
#define ID_VIEW_GRID_20			524
#define ID_VIEW_GRID_30			525
#define ID_VIEW_GRID_40			526
#define ID_VIEW_GRID_50			527
#define ID_VIEW_GRID_100		528

#define ID_PAGE_EDIT_TITLE		61
#define ID_PAGE_NEW_BLOCK		621
#define ID_PAGE_NEW_PROCESS		622
#define ID_PAGE_NEW_PROCEDURE		623
#define ID_PAGE_NEW_SERVICE		624
#define ID_PAGE_NEW_MACRO		625
#define ID_PAGE_PREV			63
#define ID_PAGE_NEXT			64
#define ID_PAGE_FIRST			65
#define ID_PAGE_LAST			66

#define ID_ANALYSIS_PTN			711
#define ID_ANALYSIS_CPN			712
#define ID_ANALYSIS_CGSPN		713
#define ID_ANALYSIS_QPN			714
#define ID_ANALYSIS_SIM			72

#define ID_TEXT_FORM			81
#define ID_NODE_TEXT			82

#endif // __CONSTANT_HXX
