///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include "sdlgeneral.hxx"
#include "sdlframe.ixx"
#include "sdlpane.ixx"

///////////////////////////////////////////////////////////////////////////

SdlPane::SdlPane(zWindow *parent, zSizer *siz, DWORD winStyle) :
		zPane(parent, siz, winStyle)
{
}

///////////////////////////////////////////////////////////////////////////

SdlPane::~SdlPane()
{
}

///////////////////////////////////////////////////////////////////////////

int SdlPane::mouseButtonDown(zMouseClickEvt *be)
{
    return ((SdlFrame*)parent())->getPage()->mouseButtonDown(canvas(),be) ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPane::mouseButtonUp(zMouseClickEvt *be)
{
    return ((SdlFrame*)parent())->getPage()->mouseButtonUp(canvas(),be) ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPane::mouseMove(zMouseMoveEvt *be)
{
    return ((SdlFrame*)parent())->getPage()->mouseMove(canvas(),be) ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPane::draw(zDrawEvt *de)
{
    return ((SdlFrame*)parent())->getPage()->draw(canvas(),de) ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPane::size(zSizeEvt*)
{
    canvas()->setDirty() ;
    return 1 ;
}

///////////////////////////////////////////////////////////////////////////
