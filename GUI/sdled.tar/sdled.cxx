///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include "sdlgeneral.hxx"
#include "sdlframe.hxx"

///////////////////////////////////////////////////////////////////////////

void zApp::main()
{
    SdlFrame *sdlWnd=new
	SdlFrame(0,new zSizer(zPoint(0,0),zDimension(576,800)),zSTDFRAME,"SDL Editor v1.1") ;
    sdlWnd->show() ;
    go() ;
    delete sdlWnd ;
}

///////////////////////////////////////////////////////////////////////////
