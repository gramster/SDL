///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDLFRAME_HXX
#define __SDLFRAME_HXX

#include "sdlclasses.hxx"
#include "sdlpage.hxx"
#include "visual.hpp"

#define MAXPANES 50

enum EditStates {STATE_CREATING, STATE_MOVING, STATE_DELETING, STATE_RESIZING} ;
enum ArcStates {ARC_FLOW_LINE, ARC_CHANNEL, ARC_SIGNAL_ROUTE} ;

//////////////////////////////////////////////////////////////////////////////

class SdlFrame : public zAppFrame
{
// Data used in a frame
    SdlPane *zP ; // pane on which sdl will draw.
    SdlPage *sp[MAXPANES]; // sDL panes/pages linked to this frame.
    zGravSizer *GravSizer ;
    int pCurrent ; // Current pane/page
    int pMax ;
    SdlNode *SdlCursor ;
    int CursorNodeType ;
    int Grid ;
    EditStates eState ;
    ArcStates aState ;
    char *fileName ;
    StatusLine *SdlStatusLine ;
    int isModified ;
// private functions used by sdlframe
    void newPage(PageType pt) ;
    void prevPage() ;
    void nextPage() ;
    void firstPage() ;
    void lastPage() ;
    void setGrid(int) ;
    void setArcState(ArcStates) ;
    void setFileName(char *newFileName) ;
    int getModified() { return isModified; };
// file functions
    void save(ostream& fout) ;
    void load(istream& fin) ;
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
public:
    SdlFrame(zWindow* parent, zSizer* siz, DWORD winStyle, const char* title);
    ~SdlFrame();
    void status(char *s) ;
    SdlPage* getPage() ;
    void setModified(int) ;
    int okCancelDlg(const char *title, const char *text) ;
    int yesNoDlg(const char *title, const char *text) ;
    int okDlg(const char *title, const char *text) ;
    int yesNoCancelDlg(const char *title, const char *text) ;
    int getGrid() { return Grid; };
    SdlNode* getCursor() { return SdlCursor; };
    int getCursorNodeType() { return CursorNodeType; };
    virtual int command(zCommandEvt *);
    EditStates getEditState() { return eState; };
    ArcStates getArcState() { return aState; };
};

//////////////////////////////////////////////////////////////////////////////

#endif // __SDLFRAME_HXX
