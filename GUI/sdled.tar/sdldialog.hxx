///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDLDIALOG_HXX
#define __SDLDIALOG_HXX

class SdlDialog : public zFormDialog
{
	zString text ;
public:
	SdlDialog(zWindow *,const zResId&, char *oldText);
	char *getText() { return (char*)text ;} ;
} ;

#endif // __SDLDIALOG_HXX
