///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include "sdlgeneral.hxx"
#include "sdlnode.ixx"
#include <string.h>
#include <math.h>

// Note: The Display is assumed to be locked, and the pen pushed.

//////////////////////////////////////////////////////////////////////////////

SdlNode::SdlNode(zPoint Pos, int type, int width, int height)
{
    Position = Pos ;
    nodeType = type ;
    xSize = width ;
    ySize = height ;
    xOffset = Pos.x() - xSize/2 ;
    yOffset = Pos.y() - ySize/2 ;
    textDescription = NULL ;
}

///////////////////////////////////////////////////////////////////////////

SdlNode::~SdlNode()
{
    delete textDescription ;
}

///////////////////////////////////////////////////////////////////////////

zRect* SdlNode::getBoundingRect()
{
    return (new zRect(xOffset, yOffset, xOffset+xSize+1, yOffset+ySize+1)) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlNode::printText(zDisplay *cv)
{
    if (getTextDescription() != NULL)
    {
	// Set a fixed font
	cv->pushFont(new zFont(AnsiFixed)) ;
	// Work out maximum characters per line.
	zDimension txtDim = cv->getTextDim("A") ; ;
	int maxChars = (width()-2)/txtDim.width() ;
	int maxLines = (height()-2)/txtDim.height() ;

	// Look through the text description and look for \n's
	char *tempText = new char [strlen(getTextDescription())+1] ;
	strcpy(tempText, getTextDescription()) ;

	int start = 0;
	int end = 0;
	int totLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    if (tempText[end] == '\n')
		end++ ;
	    start = end ;
	    totLines++ ;
	}
	if(totLines > maxLines)
	    totLines = maxLines ;
	start = end = 0 ;
	int noLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    char ctemp = tempText[end] ;
	    tempText[end] = 0 ;
	    cv->text(getCenter().x() -
		     cv->getTextDim(&(tempText[start])).width()/2,
		     getCenter().y() - txtDim.height()*(totLines)/2 +
		     txtDim.height()*noLines ,
		     &(tempText[start]));
	    tempText[end] = ctemp ;
	    if (ctemp == '\n')
		end++ ;
	    start = end ;
	    noLines++ ;
	}
	delete [] tempText ;
	delete cv->popFont() ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlBlock::printText(zDisplay *cv)
{
    cv->pushFont(new zFont(AnsiFixed)) ;
    char *temp = "BLOCK" ;
    cv->text(x()+2,y()+2,temp) ;
    if (getTextDescription() != NULL)
    {
	zDimension txtDim = cv->getTextDim(temp) ;
	cv->text(txtDim.width()+x()+12,y()+1,getTextDescription()) ;
    }
    delete cv->popFont() ;
}

///////////////////////////////////////////////////////////////////////////

void SdlText::printText(zDisplay *cv)
{
    if (getTextDescription() != NULL)
    {
	// Set a fixed font
	cv->pushFont(new zFont(AnsiFixed)) ;
	// Work out maximum characters per line.
	zDimension txtDim = cv->getTextDim("A") ; ;
	int maxChars = (width()-4)/txtDim.width() ;
	int maxLines = (height()-4)/txtDim.height() ;

	// Look through the text description and look for \n's
	char *tempText = new char [strlen(getTextDescription())+1] ;
	strcpy(tempText, getTextDescription()) ;

	int start = 0;
	int end = 0;
	int totLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    if (tempText[end] == '\n')
		end++ ;
	    start = end ;
	    totLines++ ;
	}
	if(totLines > maxLines)
	    totLines = maxLines ;
	start = end = 0 ;
	int noLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    char ctemp = tempText[end] ;
	    tempText[end] = 0 ;
	    cv->text(x() + 2,
		     getCenter().y() - txtDim.height()*(totLines)/2 +
		     txtDim.height()*noLines ,
		     &(tempText[start]));
	    tempText[end] = ctemp ;
	    if (ctemp == '\n')
		end++ ;
	    start = end ;
	    noLines++ ;
	}
	delete [] tempText ;
	delete cv->popFont() ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlBlock::draw(zDisplay *cv)
{
    cv->rectangle(x(), y(),x()+width(), y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

/*
// This is just an example of how arrows can be drawn on channel lines.
void SdlChannel::draw(zDisplay *cv)
{
    zPoint pts[3] ;

    cv->pushBrush(new zBrush(BlackBrush)) ;
    pts[0].x() = x()+width()/2-10/2 ;
    pts[0].y() = y()-6/2 ;
    pts[1].x() = x()+width()/2+10/2 ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width()/2-10/2 ;
    pts[2].y() = y()+6/2 ;
    cv->polygon(pts,3) ;
    delete cv->popBrush() ;
    cv->moveTo(x(), y()) ;
    cv->lineTo(x()+width(), y()) ;

    cv->pushBrush(new zBrush(BlackBrush)) ;
    pts[0].x() = x()+width()/3-10/2 ;
    pts[0].y() = y()+height()/2-6/2 ;
    pts[1].x() = x()+width()/3+10/2 ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()/3-10/2 ;
    pts[2].y() = y()+height()/2+6/2 ;
    cv->polygon(pts,3) ;
    delete cv->popBrush() ;
    cv->pushBrush(new zBrush(BlackBrush)) ;
    pts[0].x() = x()+width()*2/3+10/2 ;
    pts[0].y() = y()+height()/2-6/2 ;
    pts[1].x() = x()+width()*2/3-10/2 ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()*2/3+10/2 ;
    pts[2].y() = y()+height()/2+6/2 ;
    cv->polygon(pts,3) ;
    delete cv->popBrush() ;
    cv->moveTo(x(), y()+height()/2) ;
    cv->lineTo(x()+width(), y()+height()/2) ;
}
*/

///////////////////////////////////////////////////////////////////////////

void SdlConnector::draw(zDisplay *cv)
{
    cv->circle(getCenter(), height()/2) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessReference::draw(zDisplay *cv)
{
    zPoint pts[8] ;

    pts[0].x() = x()+width()/10 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/5 ;
    pts[2].x() = x() ;
    pts[2].y() = y()+height()-height()/5 ;
    pts[3].x() = x()+width()/10 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x()+width()-width()/10 ;
    pts[4].y() = y()+height() ;
    pts[5].x() = x()+width() ;
    pts[5].y() = y()+height()-height()/5 ;
    pts[6].x() = x()+width() ;
    pts[6].y() = y()+height()/5 ;
    pts[7].x() = x()+width()-width()/10 ;
    pts[7].y() = y() ;
    cv->polygon(pts,8) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessStart::draw(zDisplay *cv)
{
    cv->roundRect(x(), y(), x()+width(),
	y()+height(), height()/2, height()/2) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessState::draw(zDisplay *cv)
{
    cv->roundRect(x(), y(), x()+width(),
	y()+height(), (int)(height()/7.464), height()/2) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessInput::draw(zDisplay *cv)
{
    zPoint pts[5] ;

    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width()-height()/2 ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;
    cv->polygon(pts,5) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessOutput::draw(zDisplay *cv)
{
    zPoint pts[5] ;

    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/4 ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width() ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width()-width()/4 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;
    cv->polygon(pts,5) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessSave::draw(zDisplay *cv)
{
    zPoint pts[4] ;

    pts[0].x() = x()+width()/4 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height() ;
    pts[2].x() = x()+width()-width()/4 ;
    pts[2].y() = y()+height() ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y() ;
    cv->polygon(pts,4) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessDecision::draw(zDisplay *cv)
{
    zPoint pts[4] ;

    pts[0].x() = x()+width()/2 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()/2 ;
    pts[2].y() = y()+height() ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height()/2 ;
    cv->polygon(pts,4) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessEnable::draw(zDisplay *cv)
{
    zPoint pts[3] ;

    pts[0].x() = x()+width()/8 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()/8 ;
    pts[2].y() = y()+height() ;
    cv->polyline(pts,3) ;
    pts[0].x() = x()+width()-width()/8 ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()-width()/8 ;
    pts[2].y() = y()+height() ;
    cv->polyline(pts,3) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessStop::draw(zDisplay *cv)
{
    cv->moveTo(x()+width()/2-height()/2, y()) ;
    cv->lineTo(x()+width()/2+height()/2, y()+height()) ;
    cv->moveTo(x()+width()/2+height()/2, y()) ;
    cv->lineTo(x()+width()/2-height()/2, y()+height()) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroCall::draw(zDisplay *cv)
{
    cv->rectangle(x(), y(), x()+width(), y()+height()) ;
    cv->moveTo(x()+width()/20, y()) ;
    cv->lineTo(x()+width()/20, y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroInlet::draw(zDisplay *cv)
{
    cv->roundRect(x(), y(), x()+width(), y()+height(), height()/2, height()/2) ;
    cv->moveTo(x()+height()/2, y()) ;
    cv->lineTo(x()+height()/2, y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroOutlet::draw(zDisplay *cv)
{
    zPoint pt = getCenter() ;

    cv->circle(pt, height()/2) ;
    cv->moveTo(pt.x()-(int)(0.35355*height()), pt.y()-(int)(0.35355*height())) ;
    cv->lineTo(pt.x()-(int)(0.35355*height()), pt.y()+(int)(0.35355*height())) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlService::draw(zDisplay *cv)
{
    cv->ellipse(x(), y(), x()+width(), y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPriorityInput::draw(zDisplay *cv)
{
    zPoint pts[5] ;

    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width()-width()/4 ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;
    cv->polygon(pts,5) ;
    pts[0].x() = x()+width()-width()/20 ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/4-width()/20 ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()-width()/20 ;
    pts[2].y() = y()+height() ;
    cv->polyline(pts,3) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPriorityOutput::draw(zDisplay *cv)
{
    zPoint pts[5] ;

    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/4 ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width() ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width()-width()/4 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;
    cv->polygon(pts,5) ;
    pts[0].x() = x()+width()-width()/4-width()/20 ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/20 ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()-width()/4-width()/20 ;
    pts[2].y() = y()+height() ;
    cv->polyline(pts,3) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureReference::draw(zDisplay *cv)
{
    zPoint pts[8] ;

    pts[0].x() = x()+width()/10 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/5 ;
    pts[2].x() = x() ;
    pts[2].y() = y()+height()-height()/5 ;
    pts[3].x() = x()+width()/10 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x()+width()-width()/10 ;
    pts[4].y() = y()+height() ;
    pts[5].x() = x()+width() ;
    pts[5].y() = y()+height()-height()/5 ;
    pts[6].x() = x()+width() ;
    pts[6].y() = y()+height()/5 ;
    pts[7].x() = x()+width()-width()/10 ;
    pts[7].y() = y() ;
    cv->polygon(pts,8) ;
    cv->moveTo(pts[0]) ;
    cv->lineTo(pts[3]) ;
    cv->moveTo(pts[4]) ;
    cv->lineTo(pts[7]) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureCall::draw(zDisplay *cv)
{
    cv->rectangle(x(), y(), x()+width(), y()+height()) ;
    cv->moveTo(x()+width()/20, y()) ;
    cv->lineTo(x()+width()/20, y()+height()) ;
    cv->moveTo(x()+width()-width()/20, y()) ;
    cv->lineTo(x()+width()-width()/20, y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureReturn::draw(zDisplay *cv)
{
    zPoint pt = getCenter() ;

    cv->circle(pt, height()/2) ;
    cv->moveTo(pt.x()-(int)(0.35355*height()), pt.y()-(int)(0.35355*height())) ;
    cv->lineTo(pt.x()+(int)(0.35355*height()), pt.y()+(int)(0.35355*height())) ;
    cv->moveTo(pt.x()-(int)(0.35355*height()), pt.y()+(int)(0.35355*height())) ;
    cv->lineTo(pt.x()+(int)(0.35355*height()), pt.y()-(int)(0.35355*height())) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureStart::draw(zDisplay *cv)
{
    cv->roundRect(x(), y(), x()+width(),
	y()+height(), height()/2, height()/2) ;
    cv->moveTo(x()+height()/2, y()) ;
    cv->lineTo(x()+height()/2, y()+height()) ;
    cv->moveTo(x()+width()-height()/2, y()) ;
    cv->lineTo(x()+width()-height()/2, y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlTask::draw(zDisplay *cv)
{
    cv->rectangle(x(), y(), x()+width(), y()+height()) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlText::draw(zDisplay *cv)
{
    zPoint pts[8] ;

    pts[0].x() = x()+width()-width()/10 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y() ;
    pts[2].x() = x() ;
    pts[2].y() = y()+height() ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x()+width() ;
    pts[4].y() = y()+height()/5 ;
    pts[5].x() = x()+width()-width()/10 ;
    pts[5].y() = y()+height()/5 ;
    pts[6].x() = x()+width()-width()/10 ;
    pts[6].y() = y() ;
    pts[7].x() = x()+width() ;
    pts[7].y() = y()+height()/5 ;
    cv->polyline(pts,8) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlTransition::draw(zDisplay *cv)
{
    zPoint pts[3] ;

    pts[0].x() = x() ;
    pts[0].y() = y()+height() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y()+height() ;
    pts[2].x() = x()+(width()/2) ;
    pts[2].y() = y() ;
    cv->polygon(pts,3) ;
    printText(cv) ;
}

///////////////////////////////////////////////////////////////////////////

/*
 * To export SdlGr, we let each node output its information.  The calling
 * owner of the node needs to do the indentation.
 *
 */

///////////////////////////////////////////////////////////////////////////

void SdlNode::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlConnector::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessStart::exportSdlPr(ostream& fout)
{
    fout << "START ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessState::exportSdlPr(ostream& fout)
{
    fout << "STATE " << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessInput::exportSdlPr(ostream& fout)
{
    fout << "INPUT " << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessOutput::exportSdlPr(ostream& fout)
{
    fout << "OUTPUT " << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessSave::exportSdlPr(ostream& fout)
{
    fout << "SAVE " << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessDecision::exportSdlPr(ostream& fout)
{
    fout << "DECISION " << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessEnable::exportSdlPr(ostream& fout)
{
    fout << "ENABLE " << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessStop::exportSdlPr(ostream& fout)
{
    fout << "STOP ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroCall::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroInlet::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroOutlet::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlService::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlPriorityInput::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlPriorityOutput::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureReference::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureCall::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureReturn::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureStart::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlTask::exportSdlPr(ostream& fout)
{
    if ((strncmp(getTextDescriptionNoCr(), "SET", 3) != 0)
     && (strncmp(getTextDescriptionNoCr(), "RESET", 5) != 0))
	fout << "TASK " ;
    fout << getTextDescriptionNoCr() << " ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlText::exportSdlPr(ostream& fout)
{
    fout << getTextDescription() << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlTransition::exportSdlPr(ostream& fout)
{
}

///////////////////////////////////////////////////////////////////////////

void SdlNode::exportXFigText(ostream& fout)
{
    if (getTextDescription() != NULL)
    {
       // Work out maximum characters per line.
	int maxChars = (width()-2)/7 ;
	int maxLines = (height()-2)/12 ;

       // Look through the text description and look for \n's
	char *tempText = new char [strlen(getTextDescription())+1] ;
	strcpy(tempText, getTextDescription()) ;

	int start = 0;
	int end = 0;
	int totLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    if (tempText[end] == '\n')
		end++ ;
	    start = end ;
	    totLines++ ;
	}
	if(totLines > maxLines)
	    totLines = maxLines ;
	start = end = 0 ;
	int noLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    char ctemp = tempText[end] ;
	    tempText[end] = 0 ;
	    fout << "4 1 14 12 0 -1 0 0.00000 4 9 "
		 << strlen(&(tempText[start]))*7
		 << ' ' << getCenter().x()-1
		 << ' ' << getCenter().y()+12-1 - 12*(totLines)/2 + 12*noLines
		 << ' ' << &(tempText[start]) << '' << '\n' ;
	    tempText[end] = ctemp ;
	    if (ctemp == '\n')
		end++ ;
	    start = end ;
	    noLines++ ;
	}
	delete [] tempText ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlBlock::exportXFigText(ostream& fout)
{
    if (getTextDescription() != NULL)
    {
	fout << "4 0 14 12 0 -1 0 0.00000 4 9 "
	     << (strlen(getTextDescription())+strlen("BLOCK "))*7
	     << ' ' << x()+1
	     << ' ' << y()+12
	     << " BLOCK " ;
	fout << getTextDescription() << '' << '\n' ;
    }
    else
    {
	fout << "4 0 14 12 0 -1 0 0.00000 4 9 "
	     << strlen("BLOCK")*7
	     << ' ' << x()+1
	     << ' ' << y()+12
	     << " BLOCK\n" ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlText::exportXFigText(ostream& fout)
{
    if (getTextDescription() != NULL)
    {
	// Work out maximum characters per line.
	int maxChars = (width()-2)/7 ;
	int maxLines = (height()-2)/12 ;

	// Look through the text description and look for \n's
	char *tempText = new char [strlen(getTextDescription())+1] ;
	strcpy(tempText, getTextDescription()) ;

	int start = 0;
	int end = 0;
	int totLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    if (tempText[end] == '\n')
		end++ ;
	    start = end ;
	    totLines++ ;
	}
	if(totLines > maxLines)
	    totLines = maxLines ;
	start = end = 0 ;
	int noLines = 0 ;
	while(tempText[end] != 0)
	{
	    while((tempText[end] != '\n')
	       && (end-start <= maxChars)
	       && (tempText[end] != 0))
	    {
		end++ ;
	    }
	    char ctemp = tempText[end] ;
	    tempText[end] = 0 ;
	    fout << "4 1 14 12 0 -1 0 0.00000 4 9 "
		 << strlen(&(tempText[start]))*7
		 << ' ' << x()+1
		 << ' ' << getCenter().y()+12-1 - 12*(totLines)/2 + 12*noLines
		 << ' ' << &(tempText[start]) << '' << '\n' ;
	    tempText[end] = ctemp ;
	    if (ctemp == '\n')
		end++ ;
	    start = end ;
	    noLines++ ;
	}
	delete [] tempText ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlBlock::exportXFig(ostream& fout)
{
    fout << "2 2 0 1 -1 0 0 0 0.000 0 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlConnector::exportXFig(ostream& fout)
{
    fout << "1 3 0 1 -1 0 0 0 0.00000 1 0.000"
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << height()/2 << " " << height()/2
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << getCenter().x()+height()/2-1 << " " << getCenter().y()-1
	 << "\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessReference::exportXFig(ostream& fout)
{
    zPoint pts[8] ;
    pts[0].x() = x()+width()/10 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/5 ;
    pts[2].x() = x() ;
    pts[2].y() = y()+height()-height()/5 ;
    pts[3].x() = x()+width()/10 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x()+width()-width()/10 ;
    pts[4].y() = y()+height() ;
    pts[5].x() = x()+width() ;
    pts[5].y() = y()+height()-height()/5 ;
    pts[6].x() = x()+width() ;
    pts[6].y() = y()+height()/5 ;
    pts[7].x() = x()+width()-width()/10 ;
    pts[7].y() = y() ;

    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[5].x()-1 << " " << pts[5].y()-1
	 << " " << pts[6].x()-1 << " " << pts[6].y()-1
	 << " " << pts[7].x()-1 << " " << pts[7].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessStart::exportXFig(ostream& fout)
{
    fout << "2 4 0 1 -1 0 0 0 0.000"
	 << " " << height()/2 << " 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessState::exportXFig(ostream& fout)
{
    double xdim = height()/7.464 ; // width of triangle used for drawing arc
    double ydim = height()/2 ; // height of triangle
    int rxdim = (int)(xdim+0.5) ;
    int rydim = (int)(ydim+0.5) ;
    double alpha = atan2(ydim,xdim) ;
    double r = sqrt(xdim*xdim + ydim*ydim) ;
    double w = (r/2)/cos(alpha) ;

    fout << "6 " << x()-1-rxdim << " " << y()-1
	 << " " << x()+width()-1+rxdim << " " << y()+height()-1 << "\n" ;
    fout << "5 1 0 1 -1 0 0 0 0.000 0 0 0 "
	 << " " << x()+width()-1-w << " " << (double)getCenter().y()-1
	 << " " << x()+width()-1-rxdim << " " << y()-1
	 << " " << x()+width()-1 << " " << getCenter().y()-1
	 << " " << x()+width()-1-rxdim << " " << y()+height()-1 << "\n" ;
    fout << "5 1 0 1 -1 0 0 0 0.000 1 0 0 "
	 << " " << x()-1+w << " " << (float)getCenter().y()-1
	 << " " << x()-1+rxdim << " " << y()-1
	 << " " << x()-1 << " " << getCenter().y()-1
	 << " " << x()-1+rxdim << " " << y()+height()-1 << "\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()-1+rxdim << " " << y()-1
	 << " " << x()+width()-1-rxdim << " " << y()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()-1+rxdim << " " << y()+height()-1
	 << " " << x()+width()-1-rxdim << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessInput::exportXFig(ostream& fout)
{
    zPoint pts[5] ;
    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width()-height()/2 ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;

    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessOutput::exportXFig(ostream& fout)
{
    zPoint pts[5] ;
    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/4 ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width() ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width()-width()/4 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;

    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessSave::exportXFig(ostream& fout)
{
    zPoint pts[4] ;
    pts[0].x() = x()+width()/4 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height() ;
    pts[2].x() = x()+width()-width()/4 ;
    pts[2].y() = y()+height() ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y() ;

    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessDecision::exportXFig(ostream& fout)
{
    zPoint pts[4] ;
    pts[0].x() = x()+width()/2 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()/2 ;
    pts[2].y() = y()+height() ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height()/2 ;

    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessEnable::exportXFig(ostream& fout)
{
    zPoint pts[3] ;

    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    pts[0].x() = x()+width()/8 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()/8 ;
    pts[2].y() = y()+height() ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " 9999 9999\n" ;
    pts[0].x() = x()+width()-width()/8 ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()-width()/8 ;
    pts[2].y() = y()+height() ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcessStop::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+width()/2-height()/2-1 << " " << y()-1
	 << " " << x()+width()/2+height()/2 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+width()/2+height()/2-1 << " " << y()-1
	 << " " << x()+width()/2-height()/2-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroCall::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "2 2 0 1 -1 0 0 0 0.000 0 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+width()/20-1 << " " << y()-1
	 << " " << x()+width()/20-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroInlet::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "2 4 0 1 -1 0 0 0 0.000"
	 << " " << height()/2 << " 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+height()/2-1 << " " << y()-1
	 << " " << x()+height()/2-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlMacroOutlet::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "1 3 0 1 -1 0 0 0 0.00000 1 0.000"
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << height()/2 << " " << height()/2
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << getCenter().x()+height()/2-1 << " " << getCenter().y()-1
	 << "\n" ;
    zPoint pt = getCenter() ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pt.x()-(int)(0.35355*height())-1 << " " << pt.y()-(int)(0.35355*height())-1
         << " " << pt.x()-(int)(0.35355*height())-1 << " " << pt.y()+(int)(0.35355*height())-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlService::exportXFig(ostream& fout)
{
    fout << "1 1 0 1 -1 0 0 0 0.00000 1 0.000"
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << width()/2 << " " << height()/2
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << getCenter().x()+width()/2-1 << " " << getCenter().y()+height()-1
	 << "\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPriorityInput::exportXFig(ostream& fout)
{
    zPoint pts[5] ;
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width()-height()/2 ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;
    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    pts[0].x() = x()+width()-width()/20 ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/4-width()/20 ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()-width()/20 ;
    pts[2].y() = y()+height() ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPriorityOutput::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    zPoint pts[5] ;
    pts[0].x() = x() ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/4 ;
    pts[1].y() = y() ;
    pts[2].x() = x()+width() ;
    pts[2].y() = y()+height()/2 ;
    pts[3].x() = x()+width()-width()/4 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x() ;
    pts[4].y() = y()+height() ;
    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    pts[0].x() = x()+width()-width()/4-width()/20 ;
    pts[0].y() = y() ;
    pts[1].x() = x()+width()-width()/20 ;
    pts[1].y() = y()+height()/2 ;
    pts[2].x() = x()+width()-width()/4-width()/20 ;
    pts[2].y() = y()+height() ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureReference::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    zPoint pts[8] ;
    pts[0].x() = x()+width()/10 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y()+height()/5 ;
    pts[2].x() = x() ;
    pts[2].y() = y()+height()-height()/5 ;
    pts[3].x() = x()+width()/10 ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x()+width()-width()/10 ;
    pts[4].y() = y()+height() ;
    pts[5].x() = x()+width() ;
    pts[5].y() = y()+height()-height()/5 ;
    pts[6].x() = x()+width() ;
    pts[6].y() = y()+height()/5 ;
    pts[7].x() = x()+width()-width()/10 ;
    pts[7].y() = y() ;
    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[5].x()-1 << " " << pts[5].y()-1
	 << " " << pts[6].x()-1 << " " << pts[6].y()-1
	 << " " << pts[7].x()-1 << " " << pts[7].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[7].x()-1 << " " << pts[7].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureCall::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "2 2 0 1 -1 0 0 0 0.000 0 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+width()/20-1 << " " << y()-1
	 << " " << x()+width()/20-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+width()-width()/20-1 << " " << y()-1
	 << " " << x()+width()-width()/20-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureReturn::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "1 3 0 1 -1 0 0 0 0.00000 1 0.000"
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << height()/2 << " " << height()/2
	 << " " << getCenter().x()-1 << " " << getCenter().y()-1
	 << " " << getCenter().x()+height()/2-1 << " " << getCenter().y()-1
	 << "\n" ;
    zPoint pt = getCenter() ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pt.x()-(int)(0.35355*height())-1 << " " << pt.y()-(int)(0.35355*height())-1
         << " " << pt.x()+(int)(0.35355*height())-1 << " " << pt.y()+(int)(0.35355*height())-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pt.x()+(int)(0.35355*height())-1 << " " << pt.y()-(int)(0.35355*height())-1
         << " " << pt.x()-(int)(0.35355*height())-1 << " " << pt.y()+(int)(0.35355*height())-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
}

///////////////////////////////////////////////////////////////////////////

void SdlProcedureStart::exportXFig(ostream& fout)
{
    fout << "6 " << x()-1 << " " << y()-1
	 << " " << x()+width()-1 << " " << y()+height()-1 << "\n" ;
    fout << "2 4 0 1 -1 0 0 0 0.000"
	 << " " << height()/2 << " 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+height()/2-1 << " " << y()-1
	 << " " << x()+height()/2-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << x()+width()-height()/2-1 << " " << y()-1
	 << " " << x()+width()-height()/2-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    fout << "-6\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlTask::exportXFig(ostream& fout)
{
    fout << "2 2 0 1 -1 0 0 0 0.000 0 0 0\n"
	 << "	 " << x()+width()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()-1
	 << " " << x()-1 << " " << y()+height()-1
	 << " " << x()+width()-1 << " " << y()+height()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlText::exportXFig(ostream& fout)
{
    zPoint pts[8] ;
    pts[0].x() = x()+width()-width()/10 ;
    pts[0].y() = y() ;
    pts[1].x() = x() ;
    pts[1].y() = y() ;
    pts[2].x() = x() ;
    pts[2].y() = y()+height() ;
    pts[3].x() = x()+width() ;
    pts[3].y() = y()+height() ;
    pts[4].x() = x()+width() ;
    pts[4].y() = y()+height()/5 ;
    pts[5].x() = x()+width()-width()/10 ;
    pts[5].y() = y()+height()/5 ;
    pts[6].x() = x()+width()-width()/10 ;
    pts[6].y() = y() ;
    pts[7].x() = x()+width() ;
    pts[7].y() = y()+height()/5 ;
    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " " << pts[4].x()-1 << " " << pts[4].y()-1
	 << " " << pts[5].x()-1 << " " << pts[5].y()-1
	 << " " << pts[6].x()-1 << " " << pts[6].y()-1
	 << " " << pts[7].x()-1 << " " << pts[7].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlTransition::exportXFig(ostream& fout)
{
    zPoint pts[3] ;
    pts[0].x() = x() ;
    pts[0].y() = y()+height() ;
    pts[1].x() = x()+width() ;
    pts[1].y() = y()+height() ;
    pts[2].x() = x()+(width()/2) ;
    pts[2].y() = y() ;
    fout << "2 3 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

///////////////////////////////////////////////////////////////////////////

