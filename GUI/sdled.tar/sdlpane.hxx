///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDPANE_HXX
#define __SDPANE_HXX

#include "sdlclasses.hxx"

//////////////////////////////////////////////////////////////////////////////

class SdlPane : public zPane
{
private:
public:
    SdlPane(zWindow *parent, zSizer *siz, DWORD winStyle) ;
    ~SdlPane() ;
    virtual int draw(zDrawEvt *) ;
    virtual int size(zSizeEvt *) ;
    virtual int mouseButtonDown(zMouseClickEvt *) ;
    virtual int mouseButtonUp(zMouseClickEvt *) ;
    virtual int mouseMove(zMouseMoveEvt *) ;
};

//////////////////////////////////////////////////////////////////////////////

#endif // __SDPANE_HXX
