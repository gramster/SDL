///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include <fstream.h>
#include "sdlgeneral.hxx"
#include "sdlnode.ixx"
#include "sdlpane.ixx"
#include "sdlpage.ixx"
#include "sdlframe.ixx"
#include "sdlexport.hxx"

///////////////////////////////////////////////////////////////////////////
// This class provides the frame of the editor.  It acts as a backbone   //
// to the program, and the menu selection gets done in here.  It allows  //
// the display of several pages/panes, by using the menu to move between //
// them.  An addition could be the moving around of pages, and the	 //
// ability to delete them.						 //
///////////////////////////////////////////////////////////////////////////

SdlFrame::SdlFrame(zWindow* parent, zSizer* siz,
		   DWORD winStyle, const char* title)
	:zAppFrame(parent,siz,winStyle,title)
{
   // start up the menu
    menu(new zMenu(this, zResId(SDL_MENU))) ;

   // initialize the status line
    SdlStatusLine = new StatusLine(this,
	   new zGravSizer(ZGRAV_BOTTOM, zDimension(100,25), sizer()));
    SdlStatusLine->setupHilite();
    SdlStatusLine->show();

   // initialize all the pages/panes
    for(int i=0; i < MAXPANES; i++)
	sp[i] = NULL ;
    pCurrent = 0 ;
    pMax = 0 ;

   // initialize sundry variables
    SdlCursor = NULL ;
    Grid = 10 ;
    menu()->checkItem(ID_VIEW_GRID_10,1);
    eState = STATE_MOVING ;
    aState = ARC_FLOW_LINE ;
    menu()->checkItem(ID_CREATE_FLOW_LINE,1) ;
    setFileName(NULL) ;

   // start off by creating a page/pane with type system
    zP = new SdlPane(this, new zGravSizer(ZGRAV_MIDDLE, 0, sizer()), 
		     winStyle) ;
    sp[0] = new SdlPage(this, PAGE_SYSTEM) ;
    zP->show() ;
}

///////////////////////////////////////////////////////////////////////////

SdlFrame::~SdlFrame()
{
   // delete all the panes (Note: delete NULL is fine.)
    delete zP ;
    for(int i=0; i <= pMax; i++)
	delete sp[i] ;
    delete SdlCursor ;
    delete [] fileName ;
    delete SdlStatusLine ;
}

///////////////////////////////////////////////////////////////////////////

SdlPage* SdlFrame::getPage()
{
    return sp[pCurrent] ;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::prevPage()
{
    if (pCurrent > 0)
    {
	pCurrent-- ;
	zP->setDirty() ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::nextPage()
{
    if ((pCurrent < pMax) && (pMax < MAXPANES-1))
    {
	pCurrent++ ;
	zP->setDirty() ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::firstPage()
{
    pCurrent = 0 ;
    zP->setDirty() ;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::lastPage()
{
    pCurrent = pMax ;
    zP->setDirty() ;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::newPage(PageType pt)
// Create a new page and go to that page
{
    if (pMax < MAXPANES)
    {
	pCurrent = ++pMax ;
	sp[pMax] = new SdlPage(this, pt) ;
	zP->setDirty() ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::setGrid(int newGrid)
{
    switch (Grid)
    {
    case 1:
	menu()->checkItem(ID_VIEW_GRID_1,0);
	break ;
    case 5:
	menu()->checkItem(ID_VIEW_GRID_5,0);
	break ;
    case 10:
	menu()->checkItem(ID_VIEW_GRID_10,0);
	break ;
    case 20:
	menu()->checkItem(ID_VIEW_GRID_20,0);
	break ;
    case 30:
	menu()->checkItem(ID_VIEW_GRID_30,0);
	break ;
    case 40:
	menu()->checkItem(ID_VIEW_GRID_40,0);
	break ;
    case 50:
	menu()->checkItem(ID_VIEW_GRID_50,0);
	break ;
    case 100:
	menu()->checkItem(ID_VIEW_GRID_100,0);
	break ;
    }
    Grid = newGrid ;
    switch (Grid)
    {
    case 1:
	menu()->checkItem(ID_VIEW_GRID_1,1);
	break ;
    case 5:
	menu()->checkItem(ID_VIEW_GRID_5,1);
	break ;
    case 10:
	menu()->checkItem(ID_VIEW_GRID_10,1);
	break ;
    case 20:
	menu()->checkItem(ID_VIEW_GRID_20,1);
	break ;
    case 30:
	menu()->checkItem(ID_VIEW_GRID_30,1);
	break ;
    case 40:
	menu()->checkItem(ID_VIEW_GRID_40,1);
	break ;
    case 50:
	menu()->checkItem(ID_VIEW_GRID_50,1);
	break ;
    case 100:
	menu()->checkItem(ID_VIEW_GRID_100,1);
	break ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::setArcState(ArcStates newAState)
{
    switch (aState)
    {
    case ARC_FLOW_LINE:
	menu()->checkItem(ID_CREATE_FLOW_LINE,0) ;
	break ;
    case ARC_CHANNEL:
	menu()->checkItem(ID_CREATE_CHANNEL,0) ;
	break ;
    case ARC_SIGNAL_ROUTE:
	menu()->checkItem(ID_CREATE_SIGNAL_ROUTE,0) ;
	break ;
    }
    aState = newAState ;
    switch (aState)
    {
    case ARC_FLOW_LINE:
	menu()->checkItem(ID_CREATE_FLOW_LINE,1) ;
	break ;
    case ARC_CHANNEL:
	menu()->checkItem(ID_CREATE_CHANNEL,1) ;
	break ;
    case ARC_SIGNAL_ROUTE:
	menu()->checkItem(ID_CREATE_SIGNAL_ROUTE,1) ;
	break ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::setModified(int modi)
{
    if ((isModified && modi) || (!isModified && !modi))
    {
	return ;
    }
    isModified = modi ;
    char *currentCaption = caption() ;
    if (isModified)
    {
	char *newCaption = new
		char [strlen(currentCaption)+strlen("(modified)")+1] ;
	sprintf(newCaption, "%s(modified)", currentCaption) ;
	caption(newCaption) ;
    }
    else
    {
	*(strchr(currentCaption, '(')) = 0 ;
	caption(currentCaption) ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::setFileName(char *newFileName)
{
    char *currentCaption = caption() ;
    char *newCaption ;
    if (strchr(currentCaption, ':') != NULL)
    {
	*(strchr(currentCaption, ':')-1) = 0 ;
    }

    fileName = newFileName ;
    if (fileName == NULL)
    {
    // print noname.sgr
	newCaption = new
	    char [strlen(currentCaption)+3+strlen("noname.sgr")+1] ;
	sprintf(newCaption, "%s : noname.sgr", currentCaption) ;
    }
    else
    {
    // print filename.sgr
	newCaption = new
	    char [strlen(currentCaption)+3+strlen(strrchr(fileName,'/'))-1+1] ;
	sprintf(newCaption,"%s : %s", currentCaption,strrchr(fileName,'/')+1) ;
    }
    caption(newCaption) ;
}

///////////////////////////////////////////////////////////////////////////

int SdlFrame::okCancelDlg(const char *title, const char *text)
// from pntool
{
    zMessage *msg = new zMessage(this,title,text,MB_OKCANCEL | MB_ICONQUESTION);
    if (msg->isOk())
    {
	delete msg;
	return 1;
    }
    else
    {
	delete msg;
	return 0;
    }
}

///////////////////////////////////////////////////////////////////////////

int SdlFrame::yesNoDlg(const char *title, const char *text)
// from pntool
{
    zMessage *msg = new zMessage(this, title, text, MB_YESNO | MB_ICONQUESTION);
    if (msg->value()==IDYES)
    {
	delete msg;
	return 1;
    }
    else
    {
	delete msg;
	return 0;
    }
}

///////////////////////////////////////////////////////////////////////////

int SdlFrame::okDlg(const char *title, const char *text)
// from pntool
{
    zMessage *msg = new zMessage(this, title, text, MB_OK | MB_ICONQUESTION);
    delete msg;
    return 1;
}

///////////////////////////////////////////////////////////////////////////

int SdlFrame::yesNoCancelDlg(const char *title, const char *text)
// from pntool
{
    zMessage *msg = new zMessage(this, title, text,
				 MB_YESNOCANCEL | MB_ICONQUESTION);
    int choice = msg->value();  // one of IDYES, IDNO, IDCANCEL
    delete msg;
    return choice;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::status(char *s)
// from pntool
{
    assert(SdlStatusLine);
    SdlStatusLine->message()->printf("%s",s);
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::save(ostream& fout)
{
    for(int i=0; i <= pMax; i++)
    {
	assert (sp[i] != NULL) ;
	fout << "Page " << sp[i]->getPageType() << endl ;
	sp[i]->save(fout) ;
	fout << "EndPage" << endl ;
	fout << endl ;
    }
    status("File Saved") ;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::load(istream& fin)
{
   // Delete the old system
    zP->showSet(SW_HIDE) ;
    for(int i=0; i <= pMax; i++)
    {
	assert (sp[i] != NULL) ;
	delete sp[i] ;
	sp[i] = NULL ;
    }
    pCurrent = -1 ;
    pMax = -1 ;
    delete SdlCursor ;
    SdlCursor = NULL ;
    setGrid(10) ;
    eState = STATE_MOVING ;
    setArcState(ARC_FLOW_LINE) ;

   // Read in the new system
    char buffer[80] ;
    int temp ;

    while(!fin.eof())
    {
	fin >> buffer ;
	if (strcmp(buffer, "Page") == 0)
	{
	   // get page type
	    fin >> temp ;
	    pCurrent++ ;
	    sp[pCurrent] = new SdlPage(this, (PageType)temp) ;
	    sp[pCurrent]->load(fin) ;
	}
    }
    pMax = pCurrent ;
    firstPage() ;
    zP->showSet(SW_SHOWNORMAL) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::exportSdlPr(ostream& fout)
// Note: The exporting does not work in this version.
{
    SdlPrSystem sdlPr ;

    for(int i=0; i <= pMax; i++)
    {
	assert (sp[i] != NULL) ;
	sp[i]->exportSdlPr(
	    sdlPr.findInsert(sp[i]->getPageType(), sp[i]->getTitle())
			  ) ;
    }
    sdlPr.export(fout) ;
    status("System Exported as SDL/Pr") ;
}

///////////////////////////////////////////////////////////////////////////

void SdlFrame::exportXFig(ostream& fout)
{
    fout << "#FIG 2.1\n80 2\n" ;
    getPage()->exportXFig(fout) ;
    fout << flush ;
    status("Page exported as XFig") ;
}

///////////////////////////////////////////////////////////////////////////

SdlFrame::command(zCommandEvt *ce)
{
    zPoint oldP(0,0) ;

    switch(ce->cmd())
    {
    case ID_CREATE_BLOCK:
    case ID_CREATE_CHANNEL:
    case ID_CREATE_CONNECTOR:
    case ID_CREATE_SERVICE:
    case ID_CREATE_TEXT:
    case ID_CREATE_TASK:
    case ID_CREATE_TRANSITION:
    case ID_CREATE_MACRO_CALL:
    case ID_CREATE_MACRO_INLET:
    case ID_CREATE_MACRO_OUTLET:
    case ID_CREATE_PRIORITY_INPUT:
    case ID_CREATE_PRIORITY_OUTPUT:
    case ID_CREATE_PROCEDURE_CALL:
    case ID_CREATE_PROCEDURE_REFERENCE:
    case ID_CREATE_PROCEDURE_RETURN:
    case ID_CREATE_PROCEDURE_START:
    case ID_CREATE_PROCESS_DECISION:
    case ID_CREATE_PROCESS_ENABLE:
    case ID_CREATE_PROCESS_INPUT:
    case ID_CREATE_PROCESS_OUTPUT:
    case ID_CREATE_PROCESS_REFERENCE:
    case ID_CREATE_PROCESS_SAVE:
    case ID_CREATE_PROCESS_START:
    case ID_CREATE_PROCESS_STATE:
    case ID_CREATE_PROCESS_STOP:
	if (SdlCursor != NULL)
	    oldP = SdlCursor->getCenter();
	delete SdlCursor ;
	SdlCursor = NULL ;
	CursorNodeType = ce->cmd() ;
	eState = STATE_CREATING ;
	break ;
    }


    switch(ce->cmd())
    {
    case ID_FILE_NEW:
       // Reset to system we started with
	if(isModified)
	{
	    if(yesNoDlg("Save Current File?", "Message"))
	    {
		ofstream *fout = new ofstream(fileName) ;
		save(*fout) ;
		fout->close() ;
		delete fout ;
	    }
	}

	zP->showSet(SW_HIDE) ;
	for(int i=0; i <= pMax; i++)
	{
	    delete sp[i] ;
	    sp[i] = NULL ;
	}
	pCurrent = 0 ;
	pMax = 0 ;

	delete SdlCursor ;
	SdlCursor = NULL ;
	setGrid(10) ;
	eState = STATE_MOVING ;
	setArcState(ARC_FLOW_LINE) ;
	delete [] fileName ;
	setFileName(NULL) ;

	sp[0] = new SdlPage(this, PAGE_SYSTEM);
	zP->showSet(SW_SHOWNORMAL) ;
	setModified(0) ;
	break ;
    case ID_FILE_OPEN:
	if(isModified)
	{
	    if(yesNoDlg("Save Current File?", "Message"))
	    {
		ofstream *fout = new ofstream(fileName) ;
		save(*fout) ;
		fout->close() ;
		delete fout ;
	    }
	}
	char *types[] = {"SDL Systems (*.sgr)", "*.sgr"} ;
	zFileOpenForm *OpenFile =
	    new zFileOpenForm(this, "", fileName, types) ;
	if (OpenFile->completed() != 0)
	{
	    setModified(0) ;
	    setFileName(OpenFile->name()) ;
	    ifstream *fin = new ifstream(fileName) ;
	    load(*fin) ;
	    fin->close() ;
	    delete fin ;
	}
	break ;
    case ID_FILE_SAVE:
	setModified(0) ;
	ofstream *fout ;
	if (fileName == NULL)
	    fout = new ofstream("noname.sgr") ;
	else
	    fout = new ofstream(fileName) ;
	save(*fout) ;
	fout->close() ;
	delete fout ;
	break ;
    case ID_FILE_SAVE_AS:
	char *saveAsTypes[] = {"SDL Systems (*.sgr)", "*.sgr"} ;
	zFileSaveAsForm *SaveAsFile =
	    new zFileSaveAsForm(this, "", fileName, saveAsTypes) ;
	if (SaveAsFile->completed() != 0)
	{
	    setModified(0) ;
	    delete [] fileName ;
	    setFileName(SaveAsFile->name()) ;
	    ofstream *fout = new ofstream(fileName) ;
	    save(*fout) ;
	    fout->close() ;
	    delete fout ;
	}
	break ;
    case ID_FILE_EXPORT_SDLPR:
	char *fileExport[] = {"Textual SDL (*.spr)", "*.spr"} ;
	zFileSaveAsForm *exportFile =
	    new zFileSaveAsForm(this, "", "", fileExport) ;
	if (exportFile->completed() != 0)
	{
	    ofstream *fout = new ofstream(exportFile->name()) ;
	    exportSdlPr(*fout) ;
	    fout->close() ;
	    delete fout ;
	}
	break ;
    case ID_FILE_EXPORT_XFIG_PAGE:
	char *fileExportXFig[] = {"Xfig Page (*.fig)", "*.fig"} ;
	zFileSaveAsForm *exportFileXFig =
	    new zFileSaveAsForm(this, "", "", fileExportXFig) ;
	if (exportFileXFig->completed() != 0)
	{
	    ofstream *fout = new ofstream(exportFileXFig->name()) ;
	    exportXFig(*fout) ;
	    fout->close() ;
	    delete fout ;
	}
	break ;
    case ID_FILE_EXIT:
	if(isModified)
	{
	    if(yesNoDlg("Save Current File?", "Message"))
	    {
		ofstream *fout = new ofstream(fileName) ;
		save(*fout) ;
		fout->close() ;
		delete fout ;
	    }
	}
	app->quit() ;
	break ;

    case ID_CREATE_BLOCK:
	SdlCursor = new SdlBlock(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_CONNECTOR:
	SdlCursor = new SdlConnector(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_SERVICE:
	SdlCursor = new SdlService(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_TEXT:
	SdlCursor = new SdlText(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_TASK:
	SdlCursor = new SdlTask(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_TRANSITION:
	SdlCursor = new SdlTransition(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_MACRO_CALL:
	SdlCursor = new SdlMacroCall(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_MACRO_INLET:
	SdlCursor = new SdlMacroInlet(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_MACRO_OUTLET:
	SdlCursor = new SdlMacroOutlet(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PRIORITY_INPUT:
	SdlCursor = new SdlPriorityInput(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PRIORITY_OUTPUT:
	SdlCursor = new SdlPriorityOutput(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCEDURE_CALL:
	SdlCursor = new SdlProcedureCall(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCEDURE_REFERENCE:
	SdlCursor = new SdlProcedureReference(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCEDURE_RETURN:
	SdlCursor = new SdlProcedureReturn(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCEDURE_START:
	SdlCursor = new SdlProcedureStart(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_DECISION:
	SdlCursor = new SdlProcessDecision(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_ENABLE:
	SdlCursor = new SdlProcessEnable(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_INPUT:
	SdlCursor = new SdlProcessInput(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_OUTPUT:
	SdlCursor = new SdlProcessOutput(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_REFERENCE:
	SdlCursor = new SdlProcessReference(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_SAVE:
	SdlCursor = new SdlProcessSave(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_START:
	SdlCursor = new SdlProcessStart(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_STATE:
	SdlCursor = new SdlProcessState(oldP, ce->cmd()) ;
	break ;
    case ID_CREATE_PROCESS_STOP:
	SdlCursor = new SdlProcessStop(oldP, ce->cmd()) ;
	break ;

    case ID_CREATE_FLOW_LINE:
	setArcState(ARC_FLOW_LINE) ;
	break ;
    case ID_CREATE_CHANNEL:
	setArcState(ARC_CHANNEL) ;
	break ;
    case ID_CREATE_SIGNAL_ROUTE:
	setArcState(ARC_SIGNAL_ROUTE) ;
	break ;

    case ID_VIEW_REFRESH:
	zP->setDirty() ;
	break ;
    case ID_VIEW_GRID_1:
	setGrid(1) ;
	break ;
    case ID_VIEW_GRID_5:
	setGrid(5) ;
	break ;
    case ID_VIEW_GRID_10:
	setGrid(10) ;
	break ;
    case ID_VIEW_GRID_20:
	setGrid(20) ;
	break ;
    case ID_VIEW_GRID_30:
	setGrid(30) ;
	break ;
    case ID_VIEW_GRID_40:
	setGrid(40) ;
	break ;
    case ID_VIEW_GRID_50:
	setGrid(50) ;
	break ;
    case ID_VIEW_GRID_100:
	setGrid(100) ;
	break ;

    case ID_PAGE_EDIT_TITLE:
	getPage()->editTitle() ;
	break ;
    case ID_PAGE_NEW_BLOCK:
	newPage(PAGE_BLOCK) ;
	getPage()->editTitle() ;
	break ;
    case ID_PAGE_NEW_PROCESS:
	newPage(PAGE_PROCESS) ;
	getPage()->editTitle() ;
	break ;
    case ID_PAGE_NEW_PROCEDURE:
	newPage(PAGE_PROCEDURE) ;
	getPage()->editTitle() ;
	break ;
    case ID_PAGE_NEW_SERVICE:
	newPage(PAGE_SERVICE) ;
	getPage()->editTitle() ;
	break ;
    case ID_PAGE_NEW_MACRO:
	newPage(PAGE_MACRO) ;
	getPage()->editTitle() ;
	break ;
    case ID_PAGE_PREV:
	prevPage() ;
	break ;
    case ID_PAGE_NEXT:
	nextPage() ;
	break ;
    case ID_PAGE_FIRST:
	firstPage() ;
	break ;
    case ID_PAGE_LAST:
	lastPage() ;
	break ;

    case ID_EDIT_MOVE:
	delete SdlCursor ;
	SdlCursor = NULL ;
	assert(SdlCursor == NULL) ;
	eState = STATE_MOVING ;
	zP->setDirty() ;
	break ;
    case ID_EDIT_DELETE:
	delete SdlCursor ;
	SdlCursor = NULL ;
	assert(SdlCursor == NULL) ;
	eState = STATE_DELETING ;
	zP->setDirty() ;
	break ;
    case ID_EDIT_RESIZE:
	delete SdlCursor ;
	SdlCursor = NULL ;
	assert(SdlCursor == NULL) ;
	eState = STATE_RESIZING ;
	zP->setDirty() ;
	break ;

    case ID_ANALYSIS_PTN:
    case ID_ANALYSIS_CPN:
    case ID_ANALYSIS_CGSPN:
    case ID_ANALYSIS_QPN:
    case ID_ANALYSIS_SIM:
	break ;

    default:
	assert(0) ;
	break ;
    }
    return 1 ;
}

///////////////////////////////////////////////////////////////////////////

