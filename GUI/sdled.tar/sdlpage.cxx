///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include "sdlgeneral.hxx"
#include "sdlframe.hxx"
#include "sdlline.hxx"
#include "sdlpane.ixx"
#include "sdlnode.ixx"
#include "sdlexport.hxx"
#include "sdldialog.hxx"

///////////////////////////////////////////////////////////////////////////

SdlPage::SdlPage(zWindow *father, PageType p)
{
    pType = p ;
    nCount = -1 ;
    for (int i = 0; i < 100; i++)
	sn[i] = NULL ;
    nChange = -1 ;
    lCount = -1 ;
    for (i = 0; i < 500; i++)
	sl[i] = NULL ;
    state = STATE_LEFT ;
    pTitle = NULL ;
    dad = father ;
}

///////////////////////////////////////////////////////////////////////////

SdlPage::~SdlPage()
{
    for (int i = 0; i <= nCount; i++)
	delete sn[i] ;
    for (i = 0; i <= lCount; i++)
	delete sl[i] ;
    delete [] pTitle ;
}

///////////////////////////////////////////////////////////////////////////

char* SdlPage::getPageTypeString(PageType pt)
// returns the type of page as a character string
{
    switch(pt)
    {
    case PAGE_SYSTEM:
	return "SYSTEM" ;
    case PAGE_BLOCK:
	return "BLOCK" ;
    case PAGE_PROCESS:
	return "PROCESS" ;
    case PAGE_PROCEDURE:
	return "PROCEDURE" ;
    case PAGE_SERVICE:
	return "SERVICE" ;
    case PAGE_MACRO:
	return "MACRO" ;
    default:
	return "" ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::save(ostream& fout)
{
    fout << "Title {" ;
    if (pTitle != NULL)
	fout << pTitle ;
    fout << '}' << endl ;

    fout << endl ;
    for (int i = 0; i <= nCount; i++)
    {
	assert(sn[i] != NULL) ;
	sn[i]->save(fout) ;
	fout << endl ;
    }
    fout << endl ;
    for (i = 0; i <= lCount; i++)
    {
       // lines can only save their type.  The start and end nodes have to
       // be saved by the pane.
	assert(sl[i] != NULL) ;
	sl[i]->save(fout) ;
	fout << ' ' << findNode(sl[i]->getStart()) ;
	fout << ' ' << findNode(sl[i]->getEnd()) ;
	fout << endl ;
	fout << "LineText {" ;
	if (sl[i]->getTextDescription() != NULL)
	{
	    fout << sl[i]->getTextDescription() ;
	}
	fout << '}' << endl ;
    }
    fout << endl ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::load(istream& fin)
{
// We need not delete old system as this only gets called on a fresh sleet.

   // Read in the new nodes for this page
    char buffer[500] ;
    char c ;

    fin >> buffer ;
    while(strcmp(buffer, "EndPage") != 0)
    {
	if (strcmp(buffer, "Title") == 0)
	{
	   // get page type
	    fin >> ws >> c ; // { - used to equal out the closing brace.
	    fin.getline(buffer, 500, '}') ;
	    pTitle = new char [strlen(buffer)+1];
	    assert(pTitle != NULL) ;
	    strcpy (pTitle, buffer) ;
	}
	else
	if (strcmp(buffer, "Node") == 0)
	{
	    int type, posX, posY, width, height ;
	   // get node number and type
	    fin >> type >> posX >> posY >> width >> height ;
	    zPoint newP(posX, posY) ;
            switch (type)
	    {
	    case ID_CREATE_BLOCK:
		addNode(new SdlBlock(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_CONNECTOR:
		addNode(new SdlConnector(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_SERVICE:
		addNode(new SdlService(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_TEXT:
		addNode(new SdlText(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_TASK:
		addNode(new SdlTask(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_TRANSITION:
		addNode(new SdlTransition(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_MACRO_CALL:
		addNode(new SdlMacroCall(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_MACRO_INLET:
		addNode(new SdlMacroInlet(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_MACRO_OUTLET:
		addNode(new SdlMacroOutlet(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PRIORITY_INPUT:
		addNode(new SdlPriorityInput(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PRIORITY_OUTPUT:
		addNode(new SdlPriorityOutput(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCEDURE_CALL:
		addNode(new SdlProcedureCall(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCEDURE_REFERENCE:
		addNode(new SdlProcedureReference(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCEDURE_RETURN:
		addNode(new SdlProcedureReturn(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCEDURE_START:
		addNode(new SdlProcedureStart(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_DECISION:
		addNode(new SdlProcessDecision(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_ENABLE:
		addNode(new SdlProcessEnable(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_INPUT:
		addNode(new SdlProcessInput(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_OUTPUT:
		addNode(new SdlProcessOutput(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_REFERENCE:
		addNode(new SdlProcessReference(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_SAVE:
		addNode(new SdlProcessSave(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_START:
		addNode(new SdlProcessStart(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_STATE:
		addNode(new SdlProcessState(newP, type, width, height)) ;
		break ;
	    case ID_CREATE_PROCESS_STOP:
		addNode(new SdlProcessStop(newP, type, width, height)) ;
		break ;
	    default:
		assert(0) ;
		break ;
	    }
	}
	else
	if (strcmp(buffer, "NodeText") == 0)
	{
	   // get node Text
	    fin >> ws >> c ; // { - used to equal out the closing brace.
	    fin.getline(buffer, 500, '}') ;
	    char *textTemp = new char [strlen(buffer)+1] ;
	    assert(textTemp != NULL) ;
	    strcpy (textTemp, buffer) ;
	    sn[nCount]->setTextDescription(textTemp) ;
	}
	else
	if (strcmp(buffer, "Line") == 0)
	{
	    int type, start, end ;
	   // get line type and start and end.
	    fin >> type >> start >> end ;
            switch ((ArcStates)type)
	    {
	    case ARC_FLOW_LINE:
		addLine (new SdlFlowLine(sn[start],sn[end],(ArcStates)type)) ;
		break ;
	    case ARC_CHANNEL:
		addLine (new SdlChannel(sn[start],sn[end],(ArcStates)type)) ;
		break ;
	    case ARC_SIGNAL_ROUTE:
		addLine (new SdlSignalRoute(sn[start],sn[end],(ArcStates)type));
		break ;
	    default:
		assert(0) ;
		break ;
	    }
	}
	else
	if (strcmp(buffer, "LineText") == 0)
	{
	   // get node Text
	    fin >> ws >> c ; // { - used to equal out the closing brace.
	    fin.getline(buffer, 500, '}') ;
	    char *textTemp = new char [strlen(buffer)+1] ;
	    assert(textTemp != NULL) ;
	    strcpy (textTemp, buffer) ;
	    sl[lCount]->setTextDescription(textTemp) ;
	}
	fin >> ws >> buffer ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::followLinks(SdlPrDecisionBranch* branch, SdlNode* other)
// This follows the links from the decision branch onwards.
{
   // follow the links
    SdlPrLabel *newLabel ;
    while ((other != NULL)
	&& (other->getType() != ID_CREATE_PROCESS_DECISION)
	&& (other->getType() != ID_CREATE_PROCESS_STATE))
    {
       // find the node below the current 'other' one
	other = nextNode(other) ;
	if (other != NULL)
	{
	    newLabel = branch->append(other) ;
	    if (newLabel->getTypeLabel() == SDLPRDECISION)
	    {
	       // get all the links
		for(int i=0; i<=lCount; i++)
		{
		    if ((sl[i]->getStart() == other)
		     || (sl[i]->getEnd() == other))
		    {
			SdlNode *node ;
			if (sl[i]->getStart() == other)
			    node = sl[i]->getEnd() ;
			else
			    node = sl[i]->getStart() ;
			if(node->y() > other->y())
			{
			    SdlPrDecisionBranch *newBranch = 
				((SdlPrDecision*)newLabel)->append(
					  sl[i]->getTextDescription()) ;
			    newBranch->append(node) ;
			    followLinks(newBranch, node) ;
			   // input the nodes following into list
			}
		    }
		}
	    }
	}
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::followLinks(SdlPrInput* newInput, SdlNode* other)
{
    SdlPrLabel *newLabel ;
    while ((other != NULL)
	&& (other->getType() != ID_CREATE_PROCESS_DECISION)
	&& (other->getType() != ID_CREATE_PROCESS_STATE))
    {
	other = nextNode(other) ;
	if (other != NULL)
	{
	    newLabel = newInput->append(other) ;
	    if (newLabel->getTypeLabel() == SDLPRDECISION)
	    {
	       // get all the links
		for(int i=0; i<=lCount; i++)
		{
		    if ((sl[i]->getStart() == other)
		     || (sl[i]->getEnd() == other))
		    {
			SdlNode *node ;
			if (sl[i]->getStart() == other)
			    node = sl[i]->getEnd() ;
			else
			    node = sl[i]->getStart() ;
			if(node->y() > other->y())
			{
			    SdlPrDecisionBranch *newBranch = 
				((SdlPrDecision*)newLabel)->append(
					  sl[i]->getTextDescription()) ;
			   // input the nodes following into list
			    newBranch->append(node) ;
			    followLinks(newBranch, node) ;
			}
		    }
		}
	    }
	}
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::exportSdlPr(SdlPrPage* page)
{
    for (int i=0; i<=nCount; i++)
    {
	if (sn[i]->getType() == ID_CREATE_TEXT)
	{
	    page->insertText(sn[i]) ;
	}
	else
	if ((sn[i]->getType() == ID_CREATE_PROCESS_START)
	 || (sn[i]->getType() == ID_CREATE_PROCESS_STATE))
	{
	    SdlPrState *state = page->findInsert(sn[i]) ;
	   // Search through all the lines on that page
	   // if state node is connected to the line, then find the other
	   // node.  If this other node is lower (y-position) than the state
	   // node, then follow that thread down, until another state is
	   // reached.
	    SdlNode *other ;
	    for (int j=0; j<=lCount; j++)
	    {
		if((sl[j]->getStart() == sn[i]) || (sl[j]->getEnd() == sn[i]))
		{
		    if(sl[j]->getStart() == sn[i])
			other = sl[j]->getEnd() ;
		    else
			other = sl[j]->getStart() ;
		    if(other->y() > sn[i]->y())
		    {
			SdlPrInput *newInput = state->append(other) ;
			followLinks(newInput, other) ;
		    }
		}
	    }
	   // else search down each branch and export it, until you get to
	   // the next state.
	   // if the state has more than one connection, then search down
	   // it and put the sequence of states in state-list.
	}
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::exportXFig(ostream& fout)
{
    char *temp = getPageTypeString(pType) ;
    if (pTitle != NULL)
    {
	fout << "4 0 14 12 0 -1 0 0.00000 4 9 "
	     << (strlen(temp)+strlen(pTitle)+1)*7 // +1 for the ' '
	     << ' ' << 2
	     << ' ' << 12
	     << ' ' << temp << ' ' << pTitle << '' << '\n' ;
    }
    else
    {
	fout << "4 0 14 12 0 -1 0 0.00000 4 9 "
	     << strlen(temp)*7 
	     << ' ' << 2
	     << ' ' << 12
	     << ' ' << temp << '' << '\n' ;
    }

    for (int i = 0; i <= nCount; i++)
    {
	assert(sn[i] != NULL) ;
	sn[i]->exportXFig(fout) ;
    }
    for (i = 0; i <= lCount; i++)
    {
       // lines can only save their type.  The start and end nodes have to
       // be saved by the pane.
	assert(sl[i] != NULL) ;
	sl[i]->exportXFig(fout) ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::editTitle()
{
    SdlDialog *input =
	new SdlDialog((SdlFrame*)parent(), zResId(ID_TEXT_FORM), pTitle) ;
    assert(input != NULL) ;
    if (input->completed())
    {
	pTitle = input->getText() ;
	((SdlFrame*)parent())->setModified(1) ;
    }
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::printTitle(zDisplay *cv)
{
    cv->pushFont(new zFont(AnsiFixed)) ;
    char *temp = getPageTypeString(pType) ;
    cv->text(0,0,temp) ;
    if (pTitle != NULL)
    {
	zDimension txtDim = cv->getTextDim(temp) ;
	cv->text(txtDim.width()+10,0,pTitle) ;
    }
    delete cv->popFont() ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::addLine(SdlLine *line)
{
    lCount++ ;
    sl[lCount] = line ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::deleteLine(int Offset)
{
   // If a space is created, fill it up with the last element in the array.
    delete sl[Offset] ;
    sl[Offset] = sl[lCount] ;
    sl[lCount] = NULL ;
    lCount-- ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::findLine(zPoint p)
{
    for (int i=0; i<=lCount; i++)
    {
	assert(sl[i] != NULL) ;
	if (sl[i]->contains(p))
	{
	    return i ;
	}
    }
    return -1 ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::findLine(SdlNode *p)
{
    for (int i=0; i<=lCount; i++)
    {
	assert(sl[i] != NULL) ;
	if ((sl[i]->getStart() == p) || (sl[i]->getEnd() == p))
	{
	    return i ;
	}
    }
    return -1 ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::findLinesOnNode(SdlNode *p)
{
    int lines = 0 ;
    for (int i=0; i<=lCount; i++)
    {
	assert(sl[i] != NULL) ;
	if ((sl[i]->getStart() == p) || (sl[i]->getEnd() == p))
	{
	    lines++ ;
	}
    }
    return lines ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPage::addNode(SdlNode *node)
{
    nCount++ ;
    sn[nCount] = node ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::deleteNode(int Offset)
{
    int assocLines = 0 ;
   // Delete any associated lines.
    int foundLines ;
    while ((foundLines = findLine(sn[Offset])) != -1)
    {
	deleteLine(foundLines) ;
	assocLines = 1 ;
    }
   // If a space is created, fill it up with the last element in the array.
    delete sn[Offset] ;
    sn[Offset] = sn[nCount] ;
    sn[nCount] = NULL ;
    nCount-- ;
    return assocLines ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::findNode(zPoint p)
{
    int xMin = 30000 ;
    int found = -1 ;
    for (int i=0; i <= nCount; i++)
    {
	assert(sn[i] != NULL) ;
	if ((sn[i]->getBoundingRect())->contains(p))
	{
	    if (sn[i]->width() < xMin)
	    {
		xMin = sn[i]->width() ;
		found = i ;
	    }
	}
    }
    return found ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::findNode(SdlNode *p)
{
    for (int i=0; i <= nCount; i++)
    {
	assert(sn[i] != NULL) ;
	if (sn[i] == p)
	    return i ;
    }
    return -1 ;
}

///////////////////////////////////////////////////////////////////////////

SdlNode* SdlPage::nextNode(SdlNode *p)
{
    for (int j=0; j<=lCount; j++)
    {
	if((sl[j]->getStart() == p) || (sl[j]->getEnd() == p))
	{
	    SdlNode *other ;
	    if(sl[j]->getStart() == p)
		other = sl[j]->getEnd() ;
	    else
		other = sl[j]->getStart() ;
	    if(other->y() > p->y())
	    {
		return other ;
	    }
	}
    }
    return NULL ;
}


///////////////////////////////////////////////////////////////////////////

int SdlPage::findTopNode(int searchVector[])
{
   // find the highest node on the pane.
   // return that node

    int topNode = -1 ;
    for (int i = 0; i <= nCount; i++)
    {
	if (searchVector[i])
	{
	    if (topNode == -1)
	    {
		topNode = i ;
	    }
	    else
	    if (sn[i]->y() < sn[topNode]->y())
	    {
		topNode = i ;
	    }
	}
    }
    searchVector[topNode] = 0 ;
    return topNode ;
}

///////////////////////////////////////////////////////////////////////////

SdlNode* SdlPage::findLinkNode(SdlNode *p, int searchVector[])
{
   // find the first line that is attached to this node.
   // clear that line from the searchVector.
   // return the node that the p node is linked to.

    for (int i=0; i <= lCount; i++)
    {
	if (searchVector[i])
	{
	    if (sl[i]->getStart() == p)
	    {
		searchVector[i] = 0 ;
		return (sl[i]->getEnd()) ;
	    }
	    else if (sl[i]->getEnd() == p)
	    {
		searchVector[i] = 0 ;
		return (sl[i]->getStart()) ;
	    }
	}
    }
    return NULL ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::mouseButtonDown(zDisplay *cv, zMouseClickEvt *be)
{
    if (be->isButtonDown(1))
    {
	state = STATE_LEFT ;
	switch(((SdlFrame*)parent())->getEditState())
	{
	case STATE_CREATING:
	    if (nCount < 99)
	    {
		int SdlGrid = ((SdlFrame*)parent())->getGrid() ;
		zPoint newP(
			((((zPoint)*be).x()+SdlGrid/2)/SdlGrid)*SdlGrid ,
			((((zPoint)*be).y()+SdlGrid/2)/SdlGrid)*SdlGrid) ;

		cv->lock();

		int type = ((SdlFrame*)parent())->getCursorNodeType() ;
		switch(type)
		{
		case ID_CREATE_BLOCK:
		    addNode(new SdlBlock(newP, type)) ;
		    break ;
		case ID_CREATE_CONNECTOR:
		    addNode(new SdlConnector(newP, type)) ;
		    break ;
		case ID_CREATE_SERVICE:
		    addNode(new SdlService(newP, type)) ;
		    break ;
		case ID_CREATE_TEXT:
		    addNode(new SdlText(newP, type)) ;
		    break ;
		case ID_CREATE_TASK:
		    addNode(new SdlTask(newP, type)) ;
		    break ;
		case ID_CREATE_TRANSITION:
		    addNode(new SdlTransition(newP, type)) ;
		    break ;
		case ID_CREATE_MACRO_CALL:
		    addNode(new SdlMacroCall(newP, type)) ;
		    break ;
		case ID_CREATE_MACRO_INLET:
		    addNode(new SdlMacroInlet(newP, type)) ;
		    break ;
		case ID_CREATE_MACRO_OUTLET:
		    addNode(new SdlMacroOutlet(newP, type)) ;
		    break ;
		case ID_CREATE_PRIORITY_INPUT:
		    addNode(new SdlPriorityInput(newP, type)) ;
		    break ;
		case ID_CREATE_PRIORITY_OUTPUT:
		    addNode(new SdlPriorityOutput(newP, type)) ;
		    break ;
		case ID_CREATE_PROCEDURE_CALL:
		    addNode(new SdlProcedureCall(newP, type)) ;
		    break ;
		case ID_CREATE_PROCEDURE_REFERENCE:
		    addNode(new SdlProcedureReference(newP, type)) ;
		    break ;
		case ID_CREATE_PROCEDURE_RETURN:
		    addNode(new SdlProcedureReturn(newP, type)) ;
		    break ;
		case ID_CREATE_PROCEDURE_START:
		    addNode(new SdlProcedureStart(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_DECISION:
		    addNode(new SdlProcessDecision(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_ENABLE:
		    addNode(new SdlProcessEnable(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_INPUT:
		    addNode(new SdlProcessInput(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_OUTPUT:
		    addNode(new SdlProcessOutput(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_REFERENCE:
		    addNode(new SdlProcessReference(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_SAVE:
		    addNode(new SdlProcessSave(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_START:
		    addNode(new SdlProcessStart(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_STATE:
		    addNode(new SdlProcessState(newP, type)) ;
		    break ;
		case ID_CREATE_PROCESS_STOP:
		    addNode(new SdlProcessStop(newP, type)) ;
		    break ;
		default:
		    assert(0) ;
		    break ;
		}
		cv->unlock() ;
		((SdlFrame*)parent())->setModified(1) ;
	    }
	    else
	    {
		((SdlFrame*)parent())->status(
		    "Exceeded maximum nodes per page") ;
	    }
	    break ;
	case STATE_MOVING:
	    nChange = findNode((zPoint)*be) ;
	    if (nChange == -1)
	    {
		((SdlFrame*)parent())->status(
		    "No object found here to move.") ;
	    }
	    else
	    {
		((SdlFrame*)parent())->setModified(1) ;
	    }
	    break ;
	case STATE_DELETING:
	    int deletingNode = findNode((zPoint)*be) ;
	    if (deletingNode != -1)
	    {
		zRect *dirtyRect = sn[deletingNode]->getBoundingRect() ;
		cv->logToDev(*dirtyRect) ;
		zRectRegion dirtyArea(dirtyRect) ;
		if (deleteNode(deletingNode))
		    cv->setDirty() ;
		else
		    cv->setDirty(dirtyArea) ;
		((SdlFrame*)parent())->setModified(1) ;
	    }
	    else
	    {
		deletingNode = findLine((zPoint)*be) ;
		if (deletingNode != -1)
		{
		    deleteLine(deletingNode) ;
		    cv->setDirty() ;
		    ((SdlFrame*)parent())->setModified(1) ;
		}
		else
		{
		    ((SdlFrame*)parent())->status(
			"No object found here to delete.") ;
		}
	    }
	    break ;
	case STATE_RESIZING:
	   // Resize the object that is clicked on.
	   // It works by making the point that was clicked on, the
	   // bottom right point, and resizing the object while the
	   // user holds down the button and moves the mouse.
	    nChange = findNode((zPoint)*be) ;
	    if (nChange != -1)
	    {
		int SdlGrid = ((SdlFrame*)parent())->getGrid() ;
		int newWidth = 
		    ((((zPoint)*be).x()+SdlGrid/2)/SdlGrid)*SdlGrid -
			sn[nChange]->x() ; 
		int newHeight = 
		    ((((zPoint)*be).y()+SdlGrid/2)/SdlGrid)*SdlGrid -
			sn[nChange]->y() ;
	       // We set the old sized area as dirty, as the new
	       // will always be smaller than the old.
		zRect *dirtyRect = sn[nChange]->getBoundingRect() ;
		cv->logToDev(*dirtyRect) ;
		zRectRegion dirtyArea(dirtyRect) ;

		sn[nChange]->resize(newWidth, newHeight) ;

		if (findLine(sn[nChange]) != -1)
	       // Search for an associated line
		{
		    cv->setDirty() ;
		}
		else
		{
		    cv->setDirty(dirtyArea) ; // use old area
		}
		((SdlFrame*)parent())->setModified(1) ;
	    }
	    else
	    {
		((SdlFrame*)parent())->status(
		    "No object found here to resize.") ;
	    }
	    break ;
	default:
	    assert(0) ;
	    ((SdlFrame*)parent())->status( "ERROR: Reached invalid state") ;
	}
    }
    else if (be->isButtonDown(2))
    {
	state = STATE_MIDDLE ;
       // Connect Nodes
	nChange = findNode((zPoint)*be) ;
	if (nChange == -1)
	{
	    ((SdlFrame*)parent())->status(
		"No object found here to connect.") ;
	}
    }
    else if (be->isButtonDown(3))
    {
       // Edit Nodes
	int editingNode = findNode((zPoint)*be) ;
	if (editingNode != -1)
	{
	    SdlDialog *input =
	        new SdlDialog((SdlFrame*)parent(), zResId(ID_TEXT_FORM),
			      sn[editingNode]->getTextDescription()) ;
	    if (input->completed())
	    {
		sn[editingNode]->setTextDescription(input->getText()) ;

	       // Set area of node to dirty
		zRect *dirtyRect = sn[editingNode]->getBoundingRect() ;
		cv->logToDev(*dirtyRect) ;
		zRectRegion dirtyArea(dirtyRect) ;
		cv->setDirty(dirtyArea) ;

		((SdlFrame*)parent())->setModified(1) ;
	    }
	}
	else
	{
	    editingNode = findLine((zPoint)*be) ;
	    if (editingNode != -1)
	    {
		SdlDialog *input =
		    new SdlDialog((SdlFrame*)parent(), zResId(ID_TEXT_FORM),
			      sl[editingNode]->getTextDescription()) ;
		if (input->completed())
		{
		    sl[editingNode]->setTextDescription(input->getText()) ;
		    ((SdlFrame*)parent())->setModified(1) ;
		}
	    }
	    else
	    {
		((SdlFrame*)parent())->status(
		    "No object found here to edit.") ;
	    }
	}
       // set node area to dirty cv->setDirty() ;
	state = STATE_LEFT ;
    }
    return 1 ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::mouseButtonUp(zDisplay *cv, zMouseClickEvt *be)
{
    if (be->isButton(1))
    {
	switch(((SdlFrame*)parent())->getEditState())
	{
	case STATE_CREATING:
	    break ;
	case STATE_MOVING:
	    if (nChange != -1)
		if (findLine(sn[nChange]) != -1)
		    cv->setDirty() ;
	    nChange = -1 ;
	    break ;
	case STATE_DELETING:
	    break ;
	case STATE_RESIZING:
	    nChange = -1 ;
	    break ;
	default:
	    assert(0) ;
	    ((SdlFrame*)parent())->status( "ERROR: Reached invalid state") ;
	}
    }
    else if (be->isButton(2))
    {
       // Connect Nodes
	if (nChange != -1)
	{
	    int connectTemp = findNode((zPoint)*be) ;
	    if ((connectTemp == -1) || (nChange == connectTemp))
	    {
		nChange = -1 ;
	    }
	    else
	    {
		switch(((SdlFrame*)parent())->getArcState())
		{
		case ARC_FLOW_LINE:
		    addLine (new SdlFlowLine(sn[nChange], sn[connectTemp],
			((SdlFrame*)parent())->getArcState())) ;
		    break ;
		case ARC_CHANNEL:
		    addLine (new SdlChannel(sn[nChange], sn[connectTemp],
			((SdlFrame*)parent())->getArcState())) ;
		    break ;
		case ARC_SIGNAL_ROUTE:
		    addLine (new SdlSignalRoute(sn[nChange], sn[connectTemp],
			((SdlFrame*)parent())->getArcState())) ;
		    break ;
		default:
		    assert(0) ;
		    break ;
		}
	    }
	    cv->setDirty() ;
	    ((SdlFrame*)parent())->setModified(1) ;
	}
	nChange = -1 ;
	state = STATE_LEFT ;
    }
    return 1 ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::mouseMove(zDisplay *cv, zMouseMoveEvt *be)
{
    switch(state)
    {
    case STATE_LEFT:
	switch(((SdlFrame*)parent())->getEditState())
	{
	case STATE_CREATING:
	    if (((SdlFrame*)parent())->getCursor() != NULL)
	    {
		int SdlGrid = ((SdlFrame*)parent())->getGrid() ;
		zPoint newP(((((zPoint)*be).x()+SdlGrid/2)/SdlGrid)*SdlGrid,
			  ((((zPoint)*be).y()+SdlGrid/2)/SdlGrid)*SdlGrid) ;

		SdlNode *p = ((SdlFrame*)parent())->getCursor() ;
		if ( newP != p->getCenter())
		{
		    zRect *dirtyRect = p->getBoundingRect() ;
		    cv->logToDev(*dirtyRect) ;
		    zRectRegion dirtyArea1(dirtyRect) ;

		    ((SdlFrame*)parent())->getCursor()->move(newP) ;
		    cv->setDirty(dirtyArea1) ;
		    dirtyRect = p->getBoundingRect() ;
		    cv->logToDev(*dirtyRect) ;
		    zRectRegion dirtyArea2(dirtyRect) ;
		    cv->setDirty(dirtyArea2) ;
		}
	    }
	    break ;
	case STATE_MOVING:
	    if (nChange != -1)
	    {
		int SdlGrid = ((SdlFrame*)parent())->getGrid() ;
		zPoint newP(((((zPoint)*be).x()+SdlGrid/2)/SdlGrid)*SdlGrid,
			  ((((zPoint)*be).y()+SdlGrid/2)/SdlGrid)*SdlGrid) ;

		if ( newP != sn[nChange]->getCenter())
		{
		    zRect *dirtyRect = sn[nChange]->getBoundingRect() ;
		    cv->logToDev(*dirtyRect) ;
		    zRectRegion dirtyArea1(dirtyRect) ;

		    sn[nChange]->move(newP) ;
		   // Search for an associated line
		   // It proved to be too inefficient to update the screen
		   // each time an object got moved, so only the object that
		   // is moved is updated.
		    cv->setDirty(dirtyArea1) ;
		    dirtyRect = sn[nChange]->getBoundingRect() ;
		    cv->logToDev(*dirtyRect) ;
		    zRectRegion dirtyArea2(dirtyRect) ;
		    cv->setDirty(dirtyArea2) ;
		}
	    }
	    break ;
	case STATE_DELETING:
	    break ;
	case STATE_RESIZING:
	    if (nChange != -1)
	    {
		int SdlGrid = ((SdlFrame*)parent())->getGrid() ;
		int newWidth = 
		    ((((zPoint)*be).x()+SdlGrid/2)/SdlGrid)*SdlGrid -
			sn[nChange]->x() ; 
		int newHeight = 
		    ((((zPoint)*be).y()+SdlGrid/2)/SdlGrid)*SdlGrid -
			sn[nChange]->y() ;
		if (((newWidth != sn[nChange]->width())
		  || (newHeight != sn[nChange]->height()))
		 && (newWidth >= 0) && (newHeight >= 0))
	       // We do not accept negative widths or heights
		{
		   // if the new width is smaller than the old, or
		   // if the new height is smaller than the old, then
		   // refresh old area.
		    if (findLine(sn[nChange]) != -1)
		   // Search for an associated line
		    {
			sn[nChange]->resize(newWidth, newHeight) ;
			cv->setDirty() ;
		    }
		    else
		    {
			if ( (newWidth < sn[nChange]->width())
			  || (newHeight < sn[nChange]->height())
			   )
			{
			    zRect *dirtyRect =
				sn[nChange]->getBoundingRect() ;
			    cv->logToDev(*dirtyRect) ;
			    zRectRegion dirtyArea(dirtyRect) ;
			    sn[nChange]->resize(newWidth, newHeight) ;
			    cv->setDirty(dirtyArea) ;
			}
			else
			{
			    sn[nChange]->resize(newWidth, newHeight) ;
			    zRect *dirtyRect =
				sn[nChange]->getBoundingRect() ;
			    cv->logToDev(*dirtyRect) ;
			    zRectRegion dirtyArea(dirtyRect) ;
			    cv->setDirty(dirtyArea) ;
			}
		    }
		}
	    }
	    break ;
	default:
	    assert(0) ;
	    ((SdlFrame*)parent())->status( "ERROR: Reached invalid state") ;
	}
	break ;
    case STATE_MIDDLE:
	break ;
    case STATE_RIGHT:
	break ;
    default:
	assert(0) ;
	break ;
    }
    return 1 ;
}

///////////////////////////////////////////////////////////////////////////

int SdlPage::draw(zDisplay *cv, zDrawEvt *de)
{
    cv->lock() ;
    cv->pushPen(new zPen(BlackPen)) ;
    cv->pushBrush(new zBrush(NullBrush)) ;

    printTitle(cv) ;

    zRect r ;
    cv->getDirty(r) ;

    for(int i=0; i <= nCount; i++)
    {
	assert(sn[i] != NULL) ;
	if (r.intersects(*(sn[i]->getBoundingRect())))
	    sn[i]->draw(cv) ;
    }

    for(i=0; i <= lCount; i++)
    {
	assert(sl[i] != NULL) ;
	sl[i]->draw(cv) ;
    }

    if (((SdlFrame*)parent())->getCursor() != NULL)
	((SdlFrame*)parent())->getCursor()->draw(cv) ;

    delete cv->popBrush() ;
    delete cv->popPen() ;
    return 1 ;
}

///////////////////////////////////////////////////////////////////////////
