///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include "sdlgeneral.hxx"
#include "sdlnode.ixx"
#include "sdlline.ixx"


//////////////////////////////////////////////////////////////////////////////
// Class defines a line that can connect two nodes together.  There are 3   //
// types of lines: Flow lines, Channels & Signal routes.  Flow lines are    //
// used inside process/procedure/macro/service definitions to indicate the  //
// flow of control in the page.  Channels are characterised by connecting   //
// blocks together.  Their arrows are positioned at 2/3 the length of the   //
// line connecting the nodes.  The Signal routes arrows are positioned at   //
// the end of the line.						 	    //
//////////////////////////////////////////////////////////////////////////////

SdlLine::SdlLine(SdlNode *st, SdlNode *en, ArcStates type)
{
    start = st ;
    end = en ;
    aType = type ;
    textDescription = NULL ;
}

//////////////////////////////////////////////////////////////////////////////

SdlLine::~SdlLine()
{
    delete [] textDescription ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlLine::save(ostream& fout)
{
    fout << "Line " << aType ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlLine::printText(zDisplay* cv)
{
   // Print the text next to the bottom of the line.
    if (textDescription != NULL)
    {
	cv->pushFont(new zFont(AnsiFixed)) ;
	zDimension txtDim = cv->getTextDim(getTextDescription()) ;
	if (getStart()->getMax().y() < getEnd()->getMax().y())
	{
	   // start is above end:
	    cv->text(getEnd()->getMax().x() + 2,
	    	     getEnd()->getMax().y() - txtDim.height() - 1,
		     getTextDescription()) ;
	}
	else
	{
	   // end is above start:
	    cv->text(getStart()->getMax().x() + 2,
	    	     getStart()->getMax().y() - txtDim.height() - 1,
		     getTextDescription()) ;
	}
	delete cv->popFont() ;
    }
}

//////////////////////////////////////////////////////////////////////////////

void SdlFlowLine::draw(zDisplay* cv)
{
    printText (cv) ;
    zPoint pts[4] ;
    if (getStart()->getMax().y() < getEnd()->getMax().y())
    {
	pts[0] = getStart()->getMin() ;
	pts[3] = getEnd()->getMax() ;
    }
    else
    {
	pts[0] = getEnd()->getMin() ;
	pts[3] = getStart()->getMax() ;
    }
    pts[1].x() = pts[0].x() ;
    pts[1].y() = (pts[3].y() - pts[0].y())/2 + pts[0].y() ;

    pts[2].x() = pts[3].x() ;
    pts[2].y() = pts[1].y() ;

    cv->polyline(pts, 4) ;
}

//////////////////////////////////////////////////////////////////////////////

int SdlFlowLine::contains(zPoint p, int Accuracy)
{
    zPoint pts[4] ;
    if (getStart()->getMax().y() < getEnd()->getMax().y())
    {
	pts[0] = getStart()->getMin() ;
	pts[3] = getEnd()->getMax() ;
    }
    else
    {
	pts[0] = getEnd()->getMin() ;
	pts[3] = getStart()->getMax() ;
    }
    pts[1].x() = pts[0].x() ;
    pts[1].y() = (pts[3].y() - pts[0].y())/2 + pts[0].y() ;

    pts[2].x() = pts[3].x() ;
    pts[2].y() = pts[1].y() ;

   // point on line going down from top symbol
    if ( (p.x() >= pts[0].x()-Accuracy)
      && (p.x() <= pts[0].x()+Accuracy)
      && (p.y() >= pts[0].y())
      && (p.y() <= pts[1].y())
       )
	return 1 ;

   // point on line going down into bottom symbol
    if ( (p.x() >= pts[3].x()-Accuracy)
      && (p.x() <= pts[3].x()+Accuracy)
      && (p.y() >= pts[2].y())
      && (p.y() <= pts[3].y())
       )
	return 1 ;

   // point on line going across
    if ( (p.y() >= pts[1].y()-Accuracy)
      && (p.y() <= pts[1].y()+Accuracy)
      && (p.x() >= pts[1].x())
      && (p.x() <= pts[2].x())
       )
	return 1 ;

    return 0 ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlLine::exportXFigText(ostream& fout)
{
   // Print the text next to the bottom of the line.
    if ((textDescription != NULL) && (strcmp(textDescription, "")!=0))
    {
	if (getStart()->getMax().y() < getEnd()->getMax().y())
	{
	   // start is above end:
	    fout << "4 0 14 12 0 -1 0 0.00000 4 9 "
		 << strlen(getTextDescription())*7
		 << ' ' << getEnd()->getMax().x()+2-1
		 << ' ' << getEnd()->getMax().y()-5
		 << ' ' << getTextDescription() << '' << '\n' ;
	}
	else
	{
	   // end is above start:
	    fout << "4 0 14 12 0 -1 0 0.00000 4 9 "
		 << strlen(getTextDescription())*7
		 << ' ' << getStart()->getMax().x()+2-1
		 << ' ' << getStart()->getMax().y()-5
		 << ' ' << getTextDescription() << '' << '\n' ;
	}
    }
}

//////////////////////////////////////////////////////////////////////////////

void SdlFlowLine::exportXFig(ostream& fout)
{
    zPoint pts[4] ;
    if (getStart()->getMax().y() < getEnd()->getMax().y())
    {
	pts[0] = getStart()->getMin() ;
	pts[3] = getEnd()->getMax() ;
    }
    else
    {
	pts[0] = getEnd()->getMin() ;
	pts[3] = getStart()->getMax() ;
    }
    pts[1].x() = pts[0].x() ;
    pts[1].y() = (pts[3].y() - pts[0].y())/2 + pts[0].y() ;

    pts[2].x() = pts[3].x() ;
    pts[2].y() = pts[1].y() ;

    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << pts[0].x()-1 << " " << pts[0].y()-1
	 << " " << pts[1].x()-1 << " " << pts[1].y()-1
	 << " " << pts[2].x()-1 << " " << pts[2].y()-1
	 << " " << pts[3].x()-1 << " " << pts[3].y()-1
	 << " 9999 9999\n" ;
    exportXFigText(fout) ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlDirectLine::draw(zDisplay* cv)
{
    printText (cv) ;

   // DirectLine defines a line that is connected along the shortest
   // distance between two nodes.  It calculates the distance between the
   // possible connections between top/bottom and right/left combinations
   // and joins a line between them.

    zPoint pts[8] ;

   // Start-bottom, End-top
    pts[0] = getStart()->getMin() ;
    pts[1] = getEnd()->getMax() ;

   // End-bottom, Start-top
    pts[2] = getEnd()->getMin() ;
    pts[3] = getStart()->getMax() ;

   // Start-right, End-left
    pts[4].x() = getStart()->x() + getStart()->width() ;
    pts[4].y() = getStart()->getCenter().y() ;
    pts[5].x() = getEnd()->x() ;
    pts[5].y() = getEnd()->getCenter().y() ;

   // End-right, Start-left
    pts[6].x() = getStart()->x() ;
    pts[6].y() = getStart()->getCenter().y() ;
    pts[7].x() = getEnd()->x() + getEnd()->width() ;
    pts[7].y() = getEnd()->getCenter().y() ;

   // Find the shortest distance line
    lineStart = pts[0] ;
    lineEnd = pts[1] ;
    zPoint temp = pts[0] - pts[1] ;
    int min = temp.x()*temp.x() + temp.y()*temp.y() ;
    for (int i=2; i<8; i+=2)
    {
	temp = pts[i] - pts[i+1] ;
	int newMin = temp.x()*temp.x() + temp.y()*temp.y() ;
	if (newMin < min)
	{
	    lineStart = pts[i] ;
	    lineEnd = pts[i+1] ;
	    min = newMin ;
	}
    }

    cv->moveTo(lineStart) ;
    cv->lineTo(lineEnd) ;
}

//////////////////////////////////////////////////////////////////////////////

int SdlDirectLine::contains(zPoint p, int Accuracy)
{
//    float factor = ((float)(lineStart.x() - lineEnd.x()))
//		  /(lineStart.y() - lineEnd.y()) ;
//    if ((((float)(p.x() - Accuracy))/(p.y()) >= factor)
//     && (((float)(p.x() + Accuracy))/(p.y()) <= factor)
//     && (((float)(p.x()))/(p.y() - Accuracy) >= factor)
//     && (((float)(p.x()))/(p.y() + Accuracy) <= factor))
//	return 1 ;

    return 0 ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlDirectLine::exportXFig(ostream& fout)
{
   // DirectLine defines a line that is connected along the shortest
   // distance between two nodes.  It calculates the distance between the
   // possible connections between top/bottom and right/left combinations
   // and joins a line between them.

    zPoint pts[8] ;

   // Start-bottom, End-top
    pts[0] = getStart()->getMin() ;
    pts[1] = getEnd()->getMax() ;

   // End-bottom, Start-top
    pts[2] = getEnd()->getMin() ;
    pts[3] = getStart()->getMax() ;

   // Start-right, End-left
    pts[4].x() = getStart()->x() + getStart()->width() ;
    pts[4].y() = getStart()->getCenter().y() ;
    pts[5].x() = getEnd()->x() ;
    pts[5].y() = getEnd()->getCenter().y() ;

   // End-right, Start-left
    pts[6].x() = getStart()->x() ;
    pts[6].y() = getStart()->getCenter().y() ;
    pts[7].x() = getEnd()->x() + getEnd()->width() ;
    pts[7].y() = getEnd()->getCenter().y() ;

   // Find the shortest distance line
    lineStart = pts[0] ;
    lineEnd = pts[1] ;
    zPoint temp = pts[0] - pts[1] ;
    int min = temp.x()*temp.x() + temp.y()*temp.y() ;
    for (int i=2; i<8; i+=2)
    {
	temp = pts[i] - pts[i+1] ;
	int newMin = temp.x()*temp.x() + temp.y()*temp.y() ;
	if (newMin < min)
	{
	    lineStart = pts[i] ;
	    lineEnd = pts[i+1] ;
	    min = newMin ;
	}
    }

    fout << "2 1 0 1 -1 0 0 0 0.000 -1 0 0\n"
	 << "	 " << lineStart.x()-1 << " " << lineStart.y()-1
	 << " " << lineEnd.x()-1 << " " << lineEnd.y()-1
	 << " 9999 9999\n" ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlChannel::draw(zDisplay* cv)
{
   // draw line
    SdlDirectLine::draw(cv) ;
   // draw arrows
}

//////////////////////////////////////////////////////////////////////////////

void SdlChannel::exportXFig(ostream& fout)
{
    SdlDirectLine::exportXFig(fout) ;
}

//////////////////////////////////////////////////////////////////////////////

void SdlSignalRoute::draw(zDisplay* cv)
{
   // draw line
    SdlDirectLine::draw(cv) ;
   // draw arrows
}

//////////////////////////////////////////////////////////////////////////////

void SdlSignalRoute::exportXFig(ostream& fout)
{
    SdlDirectLine::exportXFig(fout) ;
}

//////////////////////////////////////////////////////////////////////////////
