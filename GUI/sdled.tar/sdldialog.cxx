///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include "sdlgeneral.hxx"
#include "sdldialog.hxx"

///////////////////////////////////////////////////////////////////////////
// This is a class that keeps track of the dialog box used to enter text //
// The dialog box used is very primitive and should be more refined.     //
///////////////////////////////////////////////////////////////////////////

SdlDialog::SdlDialog(zWindow *w,const zResId& rid, char *oldText)
    : zFormDialog(w,rid)
{
    if (oldText != NULL)
	text = oldText ;
    new zEditLine(this, ID_NODE_TEXT, &text);
    show();
    modal();
}

///////////////////////////////////////////////////////////////////////////

