///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDLCLASSES_HXX
#define __SDLCLASSES_HXX

class SdlFrame ;
class SdlLine ;
class SdlNode ;
class SdlPane ;
class SdlPage ;
class SdlPrSystem ;
class SdlPrPage ;
class SdlPrState ;
class SdlPrInput ;
class SdlPrLabel ;
class SdlPrNode ;
class SdlPrDecisionBranch ;
class SdlPrDecision ;

#endif // __SDLCLASSES_HXX
