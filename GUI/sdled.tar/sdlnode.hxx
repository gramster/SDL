///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDLNODE_HXX
#define __SDLNODE_HXX

#include "sdlclasses.hxx"

//////////////////////////////////////////////////////////////////////////////

class SdlNode 
{
    int xSize, ySize ;
    int xOffset, yOffset ;
    zPoint Position ;
    char *textDescription ;
    int nodeType ;
public:
    SdlNode(zPoint Pos, int type, int width=100, int height=50) ;
    virtual ~SdlNode() ;
    virtual void resize(int width, int height) ;
    virtual void save(ostream& fout) ;
    virtual void exportSdlPr(ostream& fout) ;
    virtual void exportXFig(ostream& fout) =0 ;
    virtual void exportXFigText(ostream& fout) ;
    void move(zPoint newPos) ;
    int getType() ;
    zPoint getCenter() ; // returns middle point of node
    virtual zPoint getMin() ;  // returns highest point
    virtual zPoint getMax() ;  // returns lowest point
    zCoOrd x(void) ; // returns leftmost x
    zCoOrd y(void) ; // returns topmost y
    int width(void) ; // returns xSize
    int height(void) ; // returns ySize
    void setTextDescription (char *text) ;
    char *getTextDescription () ;
    char *getTextDescriptionNoCr () ;
    virtual void printText (zDisplay* cv) ;
    virtual void draw(zDisplay* cv) =0;
    virtual zRect* getBoundingRect() ;  // returns node's bounding rectangle
};

//////////////////////////////////////////////////////////////////////////////

class SdlBlock : public SdlNode
{
public:
    void exportXFig(ostream& fout) ;
    virtual void exportXFigText(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
    virtual void printText (zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlConnector : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    SdlConnector(zPoint Pos, int type, int width=50, int height=50) ;
    virtual void resize(int width, int height) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessReference : public SdlNode
{
public:
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessStart : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessState : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessInput : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessOutput : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessSave : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessDecision : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessEnable : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcessStop : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
    virtual zPoint getMin() ;  // returns highest point
    virtual zPoint getMax() ;  // returns lowest point
};

//////////////////////////////////////////////////////////////////////////////

class SdlMacroCall : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlMacroInlet : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlMacroOutlet : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    SdlMacroOutlet(zPoint Pos, int type, int width=50, int height=50) ;
    virtual void resize(int width, int height) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlService : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};


//////////////////////////////////////////////////////////////////////////////

class SdlPriorityInput : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlPriorityOutput : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};


//////////////////////////////////////////////////////////////////////////////

class SdlProcedureReference : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcedureCall : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcedureReturn : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    SdlProcedureReturn(zPoint Pos, int type, int width=50, int height=50) ;
    virtual void resize(int width, int height) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlProcedureStart : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlTask : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlText : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void exportXFigText(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
    virtual void printText (zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlTransition : public SdlNode
{
public:
    void exportSdlPr(ostream& fout) ;
    void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};


//////////////////////////////////////////////////////////////////////////////

#endif // __SDLNODE_HXX
