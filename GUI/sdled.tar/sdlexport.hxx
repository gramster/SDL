///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDLEXPORT_HXX
#define __SDLEXPORT_HXX

#include "sdlpage.hxx"
#include "sdlnode.hxx"

class SdlPrPage ;
class SdlNode ;
class SdlPrState ;
class SdlPrInput ;
class SdlPrLabel ;
class SdlPrDecisionBranch ;
declSlist(SdlPrPage) ;
declSlist(SdlNode) ;
declSlist(SdlPrState) ;
declSlist(SdlPrInput) ;
declSlist(SdlPrLabel) ;
declSlist(SdlPrDecisionBranch) ;

class SdlPrSystem
{
   // List of pages
    SdlPrPageSlist list ;
public:
    SdlPrPage *findInsert(PageType, char* title) ;
    void export(ostream& fout) ;
};

class SdlPrPage
{
   // Page type
    PageType pType ;
    char *pTitle ;
   // List of states
    SdlPrStateSlist list ;
    SdlNodeSlist textList ;
public:
    SdlPrPage(PageType, char* title) ;
    PageType getPageType() { return pType; };
    char *getPageTitle() { return pTitle; };
    SdlPrState *findInsert(SdlNode *newState) ;
    void export(ostream& fout, int indent) ;
    void insertText(SdlNode *text) ;
};

class SdlPrState
{
    SdlNode *state ;
   // List of Inputs
    SdlPrInputSlist list ;
public:
    SdlPrState(SdlNode *newState) ;
    char *getStateText() { return state->getTextDescription() ; };
    int getStateType() { return state->getType() ; };
    SdlPrInput *append(SdlNode *input) ;
    void export(ostream& fout, int indent) ;
};

class SdlPrInput
{
   // List of nodes
    SdlPrLabelSlist list ;
public:
    SdlPrInput(SdlNode *newInput) ;
    SdlPrLabel *append(SdlNode *node) ;
    void export(ostream& fout, int indent) ;
};

enum LabelStates {SDLPRNODE, SDLPRDECISION} ;

class SdlPrLabel
{
public:
    virtual LabelStates getTypeLabel() =0 ;
    virtual void export(ostream& fout, int indent) =0 ;
};

class SdlPrNode : public SdlPrLabel
{
    SdlNode *node ;
public:
    SdlPrNode(SdlNode *newNode) { node = newNode ; };
    LabelStates getTypeLabel() { return SDLPRNODE ; };
    void export(ostream& fout, int indent) ;
};

class SdlPrDecisionBranch
{
    char *exp ;
    SdlPrLabelSlist list ;
public:
    SdlPrDecisionBranch(char *newExp) { exp = newExp ; };
    SdlPrLabel *append(SdlNode *node) ;
    void export(ostream& fout, int indent) ;
};

class SdlPrDecision : public SdlPrLabel
{
    SdlNode *decision ; // Decision expression
    SdlPrDecisionBranchSlist list ; // List of possible values/following nodes.
public:
    SdlPrDecision(SdlNode *newDecision) { decision = newDecision ; };
    LabelStates getTypeLabel() { return SDLPRDECISION ; };
    SdlPrDecisionBranch* append(char *newDecision) ;
    void export(ostream& fout, int indent) ;
};

#endif // __SDLEXPORT_HXX
