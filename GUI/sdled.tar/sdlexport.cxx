///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#include <fstream.h>
#include "sdlgeneral.hxx"
#include "sdlpage.ixx"
#include "sdlnode.ixx"
#include "sdlexport.hxx"

#define TAB 4

///////////////////////////////////////////////////////////////////////////

void SdlPrSystem::export(ostream& fout)
{
    SdlPrPageSlistIter iterator(&list) ;
    SdlPrPage *found ;
    while((found = iterator()) != NULL)
    {
	char *temp ;
	switch(found->getPageType())
	{
	case PAGE_SYSTEM:
	    temp = "SYSTEM" ;
	    break ;
	case PAGE_BLOCK:
	    temp = "BLOCK" ;
	    break ;
	case PAGE_PROCESS:
	    temp = "PROCESS" ;
	    break ;
	case PAGE_PROCEDURE:
	    temp = "PROCEDURE" ;
	    break ;
	case PAGE_SERVICE:
	    temp = "SERVICE" ;
	    break ;
	case PAGE_MACRO:
	    temp = "MACRO" ;
	    break ;
	default:
	    assert (0) ;
	}
	fout << temp << " " << found->getPageTitle() << " ;" << endl ;
	found->export(fout, TAB) ;
	fout << "END" << temp << " " << found->getPageTitle() << " ;\n" << endl;
    }
}

///////////////////////////////////////////////////////////////////////////

SdlPrPage *SdlPrSystem::findInsert(PageType type, char* title)
{
    SdlPrPageSlistIter iterator(&list) ;

    SdlPrPage *found ;

    while(((found = iterator()) != NULL)
       && ((found->getPageType() != type)
        || (strcmp(found->getPageTitle(),title) != 0)))
    {
    }

    if (found == NULL)
    {
	found = new SdlPrPage(type, title) ;
	list.append(found) ;
#ifdef DEBUG
	cout << "DEBUG:sdlexport.cxx:" << "new page " << type << title << endl ;
#endif // DEBUG
    }

    return found ;
}

///////////////////////////////////////////////////////////////////////////

SdlPrPage::SdlPrPage(PageType type, char* title)
{
    pType = type ;
    pTitle = title ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPrPage::export(ostream& fout, int indent)
{
   // First print out all the text
    SdlNodeSlistIter iteratorText(&textList) ;
    SdlNode *text ;
    while((text = iteratorText()) != NULL)
    {
	fout << '\n' ;
	text->exportSdlPr(fout) ;
    }
	
    SdlPrStateSlistIter iterator(&list) ;
    SdlPrState *found ;
    while((found = iterator()) != NULL)
    {
	found->export(fout, indent) ;
    }
}

///////////////////////////////////////////////////////////////////////////

SdlPrState *SdlPrPage::findInsert(SdlNode *newState)
{
    SdlPrStateSlistIter iterator(&list) ;

    SdlPrState *found ;

    if (newState->getType() == ID_CREATE_PROCESS_START)
    {
	while(((found = iterator()) != NULL)
	    && (found->getStateType() != ID_CREATE_PROCESS_START))
	{
	}
	if (found == NULL)
	{
	    found = new SdlPrState(newState) ;
	    list.insert(found) ;
#ifdef DEBUG
	    cout << "DEBUG:sdlexport.cxx:" << "start state " << endl ;
#endif // DEBUG
	}
	else
	{
	    assert(0) ;
#ifdef DEBUG
	    cout << "DEBUG:sdlexport.cxx:" << "more than one start" << endl ;
#endif // DEBUG
	}
    }
    else
    {
	while(((found = iterator()) != NULL)
	    && ((found->getStateType() != ID_CREATE_PROCESS_STATE)
	 || (strcmp(found->getStateText(),newState->getTextDescription()) != 0)
	       )
	     )
	{
	}
	if (found == NULL)
	{
	    found = new SdlPrState(newState) ;
	    list.append(found) ;
#ifdef DEBUG
	    cout << "DEBUG:sdlexport.cxx:" << "new state "
		 << found->getStateText() << endl ;
#endif // DEBUG
	}
    }

    return found ;
}

///////////////////////////////////////////////////////////////////////////

void  SdlPrPage::insertText(SdlNode *text)
{
    textList.append(text) ;
#ifdef DEBUG
    cout << "DEBUG:sdlexport.cxx:" << "appended text: "
	 << input->getTextDescription() << endl ;
#endif // DEBUG
}

///////////////////////////////////////////////////////////////////////////

SdlPrState::SdlPrState(SdlNode *newState)
{
    state = newState ;
}

///////////////////////////////////////////////////////////////////////////

SdlPrInput *SdlPrState::append(SdlNode *input)
{
    SdlPrInput *found = new SdlPrInput(input) ;
    list.append(found) ;
#ifdef DEBUG
    cout << "DEBUG:sdlexport.cxx:" << "appended input: "
	 << input->getTextDescription() << endl ;
#endif // DEBUG
    return found ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPrState::export(ostream& fout, int indent)
{
    fout << "\n" ;
    fout.width(indent) ;
    fout.fill(' ') ;
    fout << " " ;
    state->exportSdlPr(fout) ;
    SdlPrInputSlistIter iterator(&list) ;
    SdlPrInput *found ;
    while((found = iterator()) != NULL)
    {
	found->export(fout, indent+TAB) ;
    }
}

///////////////////////////////////////////////////////////////////////////

SdlPrInput::SdlPrInput(SdlNode *newInput)
{
    list.insert(new SdlPrNode(newInput)) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPrInput::export(ostream& fout, int indent)
{
    SdlPrLabelSlistIter iterator(&list) ;
    SdlPrLabel *found = iterator() ;
    if (found != NULL)
    {
	found->export(fout, indent) ;
	while((found = iterator()) != NULL)
	{
	    found->export(fout, indent+TAB) ;
	}
    }
}

///////////////////////////////////////////////////////////////////////////

SdlPrLabel* SdlPrInput::append(SdlNode *newNode)
{
    SdlPrLabel *found ;
    if (newNode->getType() == ID_CREATE_PROCESS_DECISION)
    {
       // Create a decision label
	found = new SdlPrDecision(newNode) ;
#ifdef DEBUG
	cout << "DEBUG:sdlexport.cxx:" << "appended decision: "
	     << newNode->getTextDescription() << endl ;
#endif // DEBUG
    }
    else
    {
       // Create a node label
	found = new SdlPrNode(newNode) ;
    }
    list.append(found) ;
    return found ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPrNode::export(ostream& fout, int indent)
{
    fout.width(indent) ;
    fout.fill(' ') ;
    fout << " " ;
    if (node->getType() == ID_CREATE_PROCESS_STATE)
	fout << "NEXT" ;
    node->exportSdlPr(fout) ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPrDecision::export(ostream& fout, int indent)
{
    assert(decision->getType() == ID_CREATE_PROCESS_DECISION) ;
    fout.width(indent) ;
    fout.fill(' ') ;
    fout << " " ;
    decision->exportSdlPr(fout) ;
    SdlPrDecisionBranchSlistIter iterator(&list) ;
    SdlPrDecisionBranch *found ;
    while((found = iterator()) != NULL)
    {
	found->export(fout, indent+TAB) ;
    }
    fout.width(indent) ;
    fout.fill(' ') ;
    fout << " " ;
    fout << "ENDDECISION ;" << endl ;
}

///////////////////////////////////////////////////////////////////////////

SdlPrDecisionBranch* SdlPrDecision::append(char *newDecision)
{
    SdlPrDecisionBranch *newBranch = new SdlPrDecisionBranch(newDecision) ;
    list.append(newBranch) ;
#ifdef DEBUG
    cout << "DEBUG:sdlexport.cxx:" << "appended decision branch: "
	 << newDecision << endl ;
#endif // DEBUG
    return newBranch ;
}

///////////////////////////////////////////////////////////////////////////

void SdlPrDecisionBranch::export(ostream& fout, int indent)
{
    fout.width(indent) ;
    fout.fill(' ') ;
    fout << " " ;
    fout << "(" << exp << ") :\n" ;
    SdlPrLabelSlistIter iterator(&list) ;
    SdlPrLabel *found ;
    while((found = iterator()) != NULL)
    {
	found->export(fout, indent+TAB) ;
    }
}

///////////////////////////////////////////////////////////////////////////

SdlPrLabel* SdlPrDecisionBranch::append(SdlNode *newNode)
{
    SdlPrLabel *found ;
    if (newNode->getType() == ID_CREATE_PROCESS_DECISION)
    {
       // Create a decision label
	found = new SdlPrDecision(newNode) ;
    }
    else
    {
       // Create a node label
	found = new SdlPrNode(newNode) ;
    }
    list.append(found) ;
#ifdef DEBUG
    cout << "DEBUG branch : " << newNode->getTextDescription() << endl ;
#endif
    return found ;
}

///////////////////////////////////////////////////////////////////////////

