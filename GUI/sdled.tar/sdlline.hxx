///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDLLINE_HXX
#define __SDLLINE_HXX

#include "sdlclasses.hxx"
#include "sdlframe.hxx"

//////////////////////////////////////////////////////////////////////////////

class SdlLine 
{
    SdlNode *start, *end ;
    ArcStates aType ;
    char *textDescription ;
public:
    SdlLine(SdlNode *st, SdlNode *en, ArcStates type) ;
    virtual ~SdlLine() ;
    virtual void draw(zDisplay* cv) =0 ;
    virtual void exportXFig(ostream& fout) =0 ;
    virtual void exportXFigText(ostream& fout) ;
    virtual void printText(zDisplay* cv) ;
    virtual int contains(zPoint p, int Accuracy=2) =0 ;
    virtual void save(ostream& fout) ;
    void setTextDescription (char *text) { textDescription = text ; };
    char *getTextDescription () { return textDescription; };
    SdlNode *getStart() { return start; };
    SdlNode *getEnd() { return end; };
};

//////////////////////////////////////////////////////////////////////////////

class SdlFlowLine : public SdlLine
{
    // The connection is drawn by taking the bottom most point of the upmost
    // node and connecting it with the top-most point of the bottom node.
public:
    virtual void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
    virtual int contains(zPoint p, int Accuracy=2) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlDirectLine : public SdlLine
{
    zPoint lineStart ;
    zPoint lineEnd ;
public:
    virtual void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
    virtual int contains(zPoint p, int Accuracy=2) ;
    zPoint getLineStart() { return lineStart; };
    zPoint getLineEnd() { return lineEnd; };
};

//////////////////////////////////////////////////////////////////////////////

class SdlChannel : public SdlDirectLine
{
public:
    virtual void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

class SdlSignalRoute : public SdlDirectLine
{
public:
    virtual void exportXFig(ostream& fout) ;
    virtual void draw(zDisplay* cv) ;
};

//////////////////////////////////////////////////////////////////////////////

#endif // __SDLLINE_HXX
