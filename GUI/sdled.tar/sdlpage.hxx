///////////////////////////////////////////////////////////////////////////
// Data Network Architectures Laboratory                                 //
// Computer Science Department                                           //
// University of Cape Town                                               //
// Rondebosch                                                            //
// South Africa                                                          //
//                                                                       //
// Author: Heinz Kabutz                                                  //
//                                                                       //
// Copyright (C) 1994. All rights reserved.                              //
// This software may not be copied or distributed in any form without the//
// written permission of either the person in charge of the Data Network //
// Architectures Laboratory or the author, Heinz Kabutz.                 //
///////////////////////////////////////////////////////////////////////////

#ifndef __SDPAGE_HXX
#define __SDPAGE_HXX

#include "sdlclasses.hxx"

enum PaneStates { STATE_LEFT, STATE_MIDDLE, STATE_RIGHT};
enum PageType { PAGE_SYSTEM, PAGE_BLOCK, PAGE_PROCESS, PAGE_PROCEDURE,
		PAGE_SERVICE, PAGE_MACRO } ;

//////////////////////////////////////////////////////////////////////////////

class SdlPage
{
private:
    int nCount ;
    SdlNode *sn[100] ;
    int nChange ;
    int lCount ;
    SdlLine *sl[500] ;
    PaneStates state ;
    PageType pType ;
    char *pTitle ;

    void addLine(SdlLine *line) ;
    void deleteLine(int Offset) ;
    int findLine(zPoint p) ;
    int findLine(SdlNode *node) ;
    void addNode(SdlNode *node) ;
    int deleteNode(int Offset) ;
    int findNode(zPoint p) ;
    int findNode(SdlNode *p) ;
    SdlNode* nextNode(SdlNode *p) ;
    void followLinks(SdlPrDecisionBranch* branch, SdlNode* other);
    void followLinks(SdlPrInput *newInput, SdlNode *other) ;
    int findLinesOnNode(SdlNode *p) ;
    int findTopNode(int searchVector[]) ;
    SdlNode* findLinkNode(SdlNode *p, int searchVector[]) ;
    static char* getPageTypeString(PageType pt) ;
    zWindow* dad ;
public:
    SdlPage(zWindow* father, PageType p) ;
    ~SdlPage() ;
    void save(ostream& fout) ;
    void load(istream& fin) ;
    void exportSdlPr(SdlPrPage* page) ;
    void exportXFig(ostream& fout) ;
    int draw(zDisplay *,zDrawEvt *) ;
    int mouseButtonDown(zDisplay *,zMouseClickEvt *) ;
    int mouseButtonUp(zDisplay *,zMouseClickEvt *) ;
    int mouseMove(zDisplay *,zMouseMoveEvt *) ;
    void editTitle() ;
    void printTitle(zDisplay *cv) ;
    char* getTitle() { return pTitle; };
    PageType getPageType() { return pType; };
    zWindow* parent() { return dad; };
};

//////////////////////////////////////////////////////////////////////////////

#endif // __SDPAGE_HXX
